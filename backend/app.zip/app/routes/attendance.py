import io
import math
from datetime import datetime, date, timedelta, timezone
from flask import Blueprint, request, jsonify, send_file, g, current_app
from flask_jwt_extended import jwt_required, get_jwt_identity, get_jwt

IST = timezone(timedelta(hours=5, minutes=30))

def get_ist_now():
    """Return current naive datetime in India Standard Time (IST, UTC+5:30)."""
    return datetime.now(IST).replace(tzinfo=None)

def get_ist_today():
    """Return current date in India Standard Time (IST, UTC+5:30)."""
    return datetime.now(IST).date()

try:
    import qrcode
except ImportError:
    qrcode = None


from app.database import db
from app.models.branch import Branch
from app.models.employee import Employee
from app.models.attendance import Attendance
from app.models.user import User

from sqlalchemy import func
from app.utils.auth import require_role, get_branch_query

attendance_bp = Blueprint("attendance", __name__, url_prefix="/api/v1/attendance")

def get_client_ip():
    """Retrieve real client public IP address from request headers or remote_addr."""
    if request.headers.get("X-Forwarded-For"):
        return request.headers.get("X-Forwarded-For").split(",")[0].strip()
    if request.headers.get("X-Real-IP"):
        return request.headers.get("X-Real-IP").strip()
    return (request.remote_addr or "").strip()

def haversine(lat1, lon1, lat2, lon2):
    """Calculate the great circle distance in meters between two points on the earth."""
    if lat1 is None or lon1 is None or lat2 is None or lon2 is None:
        return None
    try:
        R = 6371000  # Radius of Earth in meters
        dlat = math.radians(float(lat2) - float(lat1))
        dlon = math.radians(float(lon2) - float(lon1))
        a = math.sin(dlat / 2) ** 2 + math.cos(math.radians(float(lat1))) * math.cos(math.radians(float(lat2))) * math.sin(dlon / 2) ** 2
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
        return R * c
    except Exception:
        return None

@attendance_bp.route("/qr/image", methods=["GET"])
@require_role(["SuperAdmin", "ParlourAdmin", "BranchAdmin", "Employee", "Receptionist"])
def get_branch_qr_image():
    """Generate and return QR code PNG image for a branch check-in."""
    claims = get_jwt()
    tenant_id = claims.get("parlour_id") or claims.get("tenant_id")
    
    arg_b = request.args.get("branch_id")
    if arg_b is not None and str(arg_b).strip() != "":
        try:
            branch_id = int(arg_b)
        except ValueError:
            branch_id = None
    else:
        branch_id = getattr(g, "branch_id", None) or claims.get("branch_id")

    if not branch_id:
        try:
            main_branch = Branch.query.filter_by(is_main_branch=True, is_deleted=False).first()
        except Exception:
            db.session.rollback()
            main_branch = None
        if not main_branch:
            main_branch = Branch.query.filter_by(is_deleted=False).first()
        if main_branch:
            branch_id = main_branch.id

    if not branch_id:
        return jsonify({"message": "Branch ID is required"}), 400

    branch = Branch.query.filter_by(id=branch_id, is_deleted=False).first()
    if not branch:
        return jsonify({"message": "Branch not found"}), 404

    # Target tenant ID
    target_tenant_id = branch.tenant_id or getattr(g, "parlour_id", None) or tenant_id or 1

    # Build check-in URL dynamically using client origin if provided or request host
    client_origin = request.args.get("origin")
    if client_origin:
        origin = client_origin.rstrip("/")
    else:
        req_origin = request.headers.get("Origin") or request.headers.get("Referer")
        if req_origin:
            import urllib.parse
            parsed = urllib.parse.urlparse(req_origin)
            origin = f"{parsed.scheme}://{parsed.netloc}".rstrip("/")
        else:
            default_frontend = current_app.config.get("FRONTEND_URL", "https://salon.smartgonext.com")
            origin = default_frontend.rstrip("/")
        
    checkin_url = f"{origin}/attendance/checkin?branch_id={branch.id}&tenant_id={target_tenant_id}"

    # Generate QR Code image
    png_bytes = None
    try:
        import qrcode
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_M,
            box_size=10,
            border=4,
        )
        qr.add_data(checkin_url)
        qr.make(fit=True)

        img = qr.make_image(fill_color="#FF4D6D", back_color="white")
        buf = io.BytesIO()
        img.save(buf, "PNG")
        png_bytes = buf.getvalue()
    except Exception as qr_err:
        current_app.logger.warning(f"Local qrcode generation failed: {qr_err}. Attempting remote fallback...")
        import urllib.parse
        import requests
        try:
            encoded_url = urllib.parse.quote(checkin_url)
            qr_res = requests.get(
                f"https://api.qrserver.com/v1/create-qr-code/?size=300x300&data={encoded_url}&color=FF4D6D",
                timeout=5
            )
            if qr_res.status_code == 200:
                png_bytes = qr_res.content
        except Exception as fallback_err:
            current_app.logger.error(f"Fallback QR code generation failed: {fallback_err}")

    if png_bytes:
        from flask import Response
        return Response(
            png_bytes,
            mimetype="image/png",
            headers={
                "Content-Type": "image/png",
                "Content-Disposition": f'inline; filename="branch_{branch.id}_attendance_qr.png"',
                "Cache-Control": "no-cache, no-store, must-revalidate",
                "Pragma": "no-cache",
                "Expires": "0"
            }
        )

    return jsonify({"message": "QR code generation failed. Please install 'qrcode' module on server."}), 500



@attendance_bp.route("/auto-scan", methods=["POST"])
@attendance_bp.route("/checkin", methods=["POST"])
@jwt_required()
def employee_auto_scan():
    """Automatic QR scan check-in / check-out handler with strict geofence radius validation."""
    claims = get_jwt()
    identity = get_jwt_identity()
    user_id = int(identity) if identity else None
    tenant_id = claims.get("parlour_id") or claims.get("tenant_id")
    tenant_db_uri = claims.get("tenant_db_uri")

    # Ensure dynamic routing switches to Tenant DB (not Master DB)
    if tenant_id:
        try:
            with db.get_master_engine().connect() as conn:
                from sqlalchemy import text
                row = conn.execute(
                    text("SELECT db_connection_uri FROM tenants WHERE id = :id"),
                    {"id": tenant_id}
                ).fetchone()
                if row and row[0]:
                    tenant_db_uri = row[0]
        except Exception:
            pass

    g.use_master_db = False
    g.tenant_db_uri = tenant_db_uri
    g.parlour_id = tenant_id

    data = request.get_json() or {}
    scanned_branch_id = data.get("branch_id")
    lat = data.get("latitude")
    lng = data.get("longitude")

    branch = None
    if scanned_branch_id:
        try:
            b_id_int = int(scanned_branch_id)
            branch = Branch.query.filter_by(id=b_id_int, is_deleted=False).first()
            if not branch:
                branch = Branch.query.filter_by(id=b_id_int).first()
        except (ValueError, TypeError):
            pass

    # Fallback to main branch or any active branch of tenant if scanned branch ID isn't found
    if not branch:
        branch = Branch.query.filter_by(is_main_branch=True, is_deleted=False).first()
    if not branch:
        branch = Branch.query.filter_by(is_deleted=False).first()
    if not branch:
        branch = Branch.query.first()

    # Ultimate fallback: Auto-create main branch if tenant DB has no branches yet
    if not branch:
        branch = Branch(
            tenant_id=tenant_id or 1,
            name="Main Branch",
            address="Salon Address",
            is_main_branch=True,
            is_active=True
        )
        db.session.add(branch)
        db.session.commit()

    # Find corresponding Employee record for user strictly matching email or phone
    user = User.query.get(user_id) if user_id else None
    employee = None
    if user and user.email:
        u_email = (user.email or "").strip().lower()
        u_prefix = u_email.split("@")[0] if "@" in u_email else u_email
        all_emps = Employee.query.filter_by(is_deleted=False).all()
        
        # 1. Exact match by email/phone or exact name
        for e in all_emps:
            e_phone = (e.phone or "").strip().lower()
            e_fn = (e.first_name or "").strip().lower()
            e_full = f"{e.first_name or ''} {e.last_name or ''}".strip().lower()
            if u_email == e_phone or u_prefix == e_fn or u_prefix == e_full:
                employee = e
                break

        # 2. Substring match fallback
        if not employee:
            for e in all_emps:
                e_phone = (e.phone or "").strip().lower()
                e_fn = (e.first_name or "").strip().lower()
                if (e_phone and e_phone in u_email) or (e_fn and e_fn in u_prefix):
                    employee = e
                    break

    # If no existing employee matched for user, auto-create a dedicated Employee record for this user
    if not employee and user:
        emp_name = user.email.split("@")[0].title() if user.email else "Staff"
        employee = Employee(
            tenant_id=tenant_id or 1,
            branch_id=branch.id,
            first_name=emp_name,
            phone=user.email or "9999999999",
            role=user.role or "Employee",
            status="active"
        )
        db.session.add(employee)
        db.session.commit()

    if not employee:
        return jsonify({"status": "error", "message": "No active Employee profile found for your account."}), 400

    # Locate today's attendance record for this employee (across ANY branch for today)
    today_curr = get_ist_today()
    today_start = datetime.combine(today_curr, datetime.min.time())
    today_end = datetime.combine(today_curr, datetime.max.time())

    existing = Attendance.query.filter_by(
        employee_id=employee.id
    ).filter(Attendance.timestamp >= today_start, Attendance.timestamp <= today_end).order_by(Attendance.timestamp.desc()).first()

    # Calculate geofence distance & check Wi-Fi network verification
    test_mode = data.get("test_mode", False)

    # 0. Check Salon Wi-Fi Network Attendance Verification
    if branch.enforce_wifi and branch.wifi_public_ip and not test_mode:
        client_ip = get_client_ip()
        branch_ip = branch.wifi_public_ip.strip()
        is_ip_match = (client_ip == branch_ip) or (client_ip in ("127.0.0.1", "localhost", "::1") and branch_ip in ("127.0.0.1", "localhost", "::1"))
        if not is_ip_match:
            wifi_name = branch.wifi_ssid or "Parlour Wi-Fi"
            return jsonify({
                "status": "error",
                "error_code": "WIFI_MISMATCH",
                "message": f"❌ Attendance Rejected: You must be connected to the Salon Wi-Fi ('{wifi_name}') to record attendance.",
                "detected_ip": client_ip,
                "required_wifi": wifi_name
            }), 400

    distance_meters = 0.0 if test_mode else None

    if test_mode and branch.latitude is not None and branch.longitude is not None:
        lat = branch.latitude
        lng = branch.longitude
        distance_meters = 0.0

    if not test_mode and branch.latitude is not None and branch.longitude is not None:
        if lat is None or lng is None:
            return jsonify({
                "status": "error",
                "message": "❌ Action Failed: Location access is disabled. Please enable GPS location on your phone."
            }), 400

        distance_meters = haversine(lat, lng, branch.latitude, branch.longitude)

    # If previously marked on Leave / Day Off, allow checking in as Present today
    if existing and existing.status in ["L", "OFF"]:
        now = get_ist_now()
        existing.status = "P"
        existing.timestamp = now
        existing.checkin_method = "Wi-Fi" if (branch.enforce_wifi and branch.wifi_public_ip) else "QR"
        existing.branch_id = branch.id
        db.session.commit()
        cin_time = now.strftime("%I:%M %p")
        return jsonify({
            "status": "success",
            "action": "checkin",
            "message": f"✅ Check-in recorded at {branch.name} at {cin_time}. Attendance status updated to Present (Full Day).",
            "data": {
                "id": existing.id,
                "checkin_time": cin_time,
                "branch_name": branch.name,
                "status": "P"
            }
        }), 200

    # 1. ALREADY CHECKED IN AND CHECKED OUT TODAY -> SHOW COMPLETED STATUS NOTICE
    if existing and existing.check_out_time:
        cin_time = existing.timestamp.strftime("%I:%M %p")
        cout_time = existing.check_out_time.strftime("%I:%M %p")
        return jsonify({
            "status": "error",
            "message": f"You have already completed attendance for today (Checked in: {cin_time}, Checked out: {cout_time}).",
            "data": {
                "id": existing.id,
                "checkin_time": cin_time,
                "checkout_time": cout_time,
                "branch_name": branch.name,
                "status": existing.status
            }
        }), 400

    # 2. CHECKED IN, BUT NOT CHECKED OUT YET -> AUTOMATIC CHECK-OUT ATTEMPT
    if existing and not existing.check_out_time:
        now = get_ist_now()
        elapsed_mins = (now - existing.timestamp).total_seconds() / 60.0
        if elapsed_mins < 30:
            cin_time = existing.timestamp.strftime("%I:%M %p")
            return jsonify({
                "status": "error",
                "message": f"Already marked attendance for today (Checked in at {cin_time}). Please scan again closer to your shift end time to check out."
            }), 400

        if branch.latitude is not None and branch.longitude is not None:
            radius = float(branch.geofence_radius_meters or 100)
            if distance_meters is None or distance_meters > radius:
                dist_val = int(round(distance_meters)) if distance_meters is not None else 0
                return jsonify({
                    "status": "error",
                    "message": f"❌ Check-out Failed: You are {dist_val}m away from {branch.name}. You must be within {int(radius)}m to check out."
                }), 400

        existing.check_out_time = now

        # Auto P vs HP status calculation based on shift duration
        op_mins = parse_time_str(branch.opening_time or "09:00") or (9 * 60)
        cl_mins = parse_time_str(branch.closing_time or "21:00") or (21 * 60)
        expected_duration_mins = max(cl_mins - op_mins, 60)

        worked_mins = (now - existing.timestamp).total_seconds() / 60.0
        if worked_mins >= (0.5 * expected_duration_mins):
            existing.status = "P"
        else:
            existing.status = "HP"

        db.session.commit()

        status_label = "Full Day (Present)" if existing.status == "P" else "Half Day (HP)"
        cout_time = now.strftime("%I:%M %p")
        return jsonify({
            "status": "success",
            "action": "checkout",
            "message": f"✅ Checked out successfully at {branch.name} at {cout_time}. Attendance marked as {status_label}.",
            "data": {
                "id": existing.id,
                "checkout_time": cout_time,
                "branch_name": branch.name,
                "status": existing.status
            }
        }), 200

    # 3. NO ATTENDANCE TODAY YET -> AUTOMATIC CHECK-IN ATTEMPT
    if branch.latitude is not None and branch.longitude is not None:
        radius = float(branch.geofence_radius_meters or 100)
        if distance_meters is None or distance_meters > radius:
            dist_val = int(round(distance_meters)) if distance_meters is not None else 0
            return jsonify({
                "status": "error",
                "message": f"❌ Check-in Failed: You are {dist_val}m away from {branch.name}. You must be within {int(radius)}m to check in."
            }), 400

    now = get_ist_now()
    attendance = Attendance(
        tenant_id=tenant_id or 1,
        employee_id=employee.id,
        branch_id=branch.id,
        timestamp=now,
        checkin_method="QR",
        location_flagged=False,
        location_unavailable=False,
        latitude=lat,
        longitude=lng,
        distance_meters=round(distance_meters, 2) if distance_meters is not None else None,
        status="P"
    )

    db.session.add(attendance)
    db.session.commit()

    cin_time = now.strftime("%I:%M %p")
    return jsonify({
        "status": "success",
        "action": "checkin",
        "message": f"✅ Checked in successfully at {branch.name} at {cin_time}.",
        "data": {
            "id": attendance.id,
            "employee_name": f"{employee.first_name} {employee.last_name or ''}".strip(),
            "branch_name": branch.name,
            "timestamp": now.strftime("%Y-%m-%d %I:%M %p"),
            "checkin_time": cin_time,
            "distance_meters": attendance.distance_meters
        }
    }), 201


@attendance_bp.route("", methods=["GET"])
@require_role(["ParlourAdmin", "BranchAdmin", "SuperAdmin", "Receptionist", "Employee"])
def get_attendance_logs():
    """Retrieve tenant & branch-scoped attendance logs for admin reporting."""
    claims = get_jwt()
    role = claims.get("role")
    start_date = request.args.get("start_date")
    end_date = request.args.get("end_date")

    query = get_branch_query(Attendance)

    if role == "Employee":
        identity = get_jwt_identity()
        user_id = int(identity) if identity else None
        user = User.query.get(user_id) if user_id else None
        if user and user.email:
            u_email = (user.email or "").strip().lower()
            u_prefix = u_email.split("@")[0] if "@" in u_email else u_email
            matched_emp = Employee.query.filter(
                (Employee.phone == user.email) | 
                (func.lower(Employee.first_name) == u_prefix) |
                (func.lower(Employee.first_name + " " + func.coalesce(Employee.last_name, "")) == u_prefix)
            ).first()
            if matched_emp:
                query = query.filter(Attendance.employee_id == matched_emp.id)

    if start_date:
        try:
            s_dt = datetime.strptime(start_date, "%Y-%m-%d")
            query = query.filter(Attendance.timestamp >= s_dt)
        except ValueError:
            pass

    if end_date:
        try:
            e_dt = datetime.strptime(end_date + " 23:59:59", "%Y-%m-%d %H:%M:%S")
            query = query.filter(Attendance.timestamp <= e_dt)
        except ValueError:
            pass

    try:
        records = query.order_by(Attendance.timestamp.desc()).all()
    except Exception as e:
        db.session.rollback()
        records = []

    result = []
    for att in records:
        emp = Employee.query.get(att.employee_id)
        br = Branch.query.get(att.branch_id)
        home_br = Branch.query.get(emp.branch_id) if (emp and emp.branch_id) else None

        result.append({
            "id": att.id,
            "employee_id": att.employee_id,
            "employee_name": f"{emp.first_name} {emp.last_name or ''}".strip() if emp else "Unknown Staff",
            "employee_phone": emp.phone if emp else "",
            "home_branch_name": home_br.name if home_br else (br.name if br else "Main Parlour"),
            "work_branch_id": att.branch_id,
            "work_branch_name": br.name if br else "Main Parlour",
            "timestamp": att.timestamp.strftime("%Y-%m-%d %H:%M:%S"),
            "checkin_time": att.timestamp.strftime("%I:%M %p"),
            "checkout_time": att.check_out_time.strftime("%I:%M %p") if att.check_out_time else "-",
            "date": att.timestamp.strftime("%Y-%m-%d"),
            "time": att.timestamp.strftime("%I:%M %p"),
            "checkin_method": att.checkin_method,
            "location_flagged": att.location_flagged,
            "location_unavailable": att.location_unavailable,
            "latitude": float(att.latitude) if att.latitude else None,
            "longitude": float(att.longitude) if att.longitude else None,
            "distance_meters": float(att.distance_meters) if att.distance_meters else None,
            "status": getattr(att, "status", "P") or "P"
        })

    return jsonify({"status": "success", "data": result})


def parse_time_str(time_str):
    """Convert HH:MM string into minutes from midnight."""
    try:
        parts = time_str.strip().split(":")
        return int(parts[0]) * 60 + int(parts[1])
    except Exception:
        return None


@attendance_bp.route("/checkout", methods=["POST"])
@jwt_required()
def employee_checkout():
    """Record employee QR check-out with strict geofence radius validation and auto P/HP calculation."""
    claims = get_jwt()
    identity = get_jwt_identity()
    user_id = int(identity) if identity else None
    tenant_id = claims.get("parlour_id") or claims.get("tenant_id")

    data = request.get_json() or {}
    scanned_branch_id = data.get("branch_id")
    lat = data.get("latitude")
    lng = data.get("longitude")

    if not scanned_branch_id:
        return jsonify({"status": "error", "message": "Branch ID is required from QR scan"}), 400

    branch = Branch.query.filter_by(id=scanned_branch_id).first()
    if not branch:
        return jsonify({"status": "error", "message": "Invalid or inactive parlour branch QR code"}), 404

    user = User.query.get(user_id) if user_id else None
    employee = None
    if user and user.email:
        employee = Employee.query.filter(
            (Employee.phone == user.email) | (Employee.first_name + " " + (Employee.last_name or "") == user.email)
        ).first()

    if not employee:
        employee = Employee.query.first()

    if not employee:
        return jsonify({"status": "error", "message": "No active Employee profile linked to this user account"}), 400

    today_curr = get_ist_today()
    today_start = datetime.combine(today_curr, datetime.min.time())
    today_end = datetime.combine(today_curr, datetime.max.time())

    attendance = Attendance.query.filter_by(
        employee_id=employee.id,
        branch_id=branch.id
    ).filter(Attendance.timestamp >= today_start, Attendance.timestamp <= today_end).first()

    if not attendance:
        return jsonify({
            "status": "error",
            "message": "❌ Check-out Failed: No check-in record found for today. Please check in first."
        }), 400

    if attendance.check_out_time:
        return jsonify({
            "status": "error",
            "message": f"You have already checked out today at {attendance.check_out_time.strftime('%I:%M %p')}."
        }), 400

    # Wi-Fi network verification
    if branch.enforce_wifi and branch.wifi_public_ip:
        client_ip = get_client_ip()
        branch_ip = branch.wifi_public_ip.strip()
        is_ip_match = (client_ip == branch_ip) or (client_ip in ("127.0.0.1", "localhost", "::1") and branch_ip in ("127.0.0.1", "localhost", "::1"))
        if not is_ip_match:
            wifi_name = branch.wifi_ssid or "Parlour Wi-Fi"
            return jsonify({
                "status": "error",
                "error_code": "WIFI_MISMATCH",
                "message": f"❌ Check-out Rejected: You must be connected to the Salon Wi-Fi ('{wifi_name}') to check out.",
                "detected_ip": client_ip,
                "required_wifi": wifi_name
            }), 400

    # Strict Geofence Validation
    distance_meters = None
    if branch.latitude is not None and branch.longitude is not None:
        if lat is None or lng is None:
            return jsonify({
                "status": "error",
                "message": "❌ Check-out Failed: Location permissions disabled. Enable location to check out."
            }), 400

        distance_meters = haversine(lat, lng, branch.latitude, branch.longitude)
        radius = branch.geofence_radius_meters or 100

        if distance_meters is None or distance_meters > radius:
            dist_val = int(distance_meters) if distance_meters is not None else 0
            return jsonify({
                "status": "error",
                "message": f"❌ Check-out Failed: You are {dist_val}m away from {branch.name}. Must be within {radius}m to check out."
            }), 400

    # Set check_out_time
    now = get_ist_now()
    attendance.check_out_time = now

    # Auto-calculate P vs HP status based on shift duration
    op_mins = parse_time_str(branch.opening_time or "09:00") or (9 * 60)
    cl_mins = parse_time_str(branch.closing_time or "21:00") or (21 * 60)
    expected_duration_mins = max(cl_mins - op_mins, 60)  # at least 1 hour

    worked_seconds = (now - attendance.timestamp).total_seconds()
    worked_mins = worked_seconds / 60.0

    if worked_mins >= (0.5 * expected_duration_mins):
        attendance.status = "P"
    else:
        attendance.status = "HP"

    db.session.commit()

    status_label = "Full Day (Present)" if attendance.status == "P" else "Half Day (HP)"

    return jsonify({
        "status": "success",
        "message": f"✅ Checked out successfully at {now.strftime('%I:%M %p')}. Attendance marked as {status_label}.",
        "data": {
            "id": attendance.id,
            "check_out_time": now.strftime("%Y-%m-%d %I:%M %p"),
            "status": attendance.status
        }
    })


@attendance_bp.route("/<int:attendance_id>/status", methods=["PUT"])
@jwt_required()
def override_attendance_status(attendance_id):
    """Admin endpoint to manually override attendance status (P / HP / OFF)."""
    claims = get_jwt()
    role = claims.get("role")
    if role not in ["ParlourAdmin", "BranchAdmin", "SuperAdmin"]:
        return jsonify({"status": "error", "message": "Unauthorized"}), 403

    data = request.get_json() or {}
    new_status = data.get("status", "").upper()
    if new_status not in ["P", "HP", "OFF"]:
        return jsonify({"status": "error", "message": "Status must be P, HP, or OFF"}), 400

    attendance = Attendance.query.get(attendance_id)
    if not attendance:
        return jsonify({"status": "error", "message": "Attendance record not found"}), 404

    attendance.status = new_status
    db.session.commit()

    return jsonify({"status": "success", "message": f"Attendance status updated to {new_status}"})


@attendance_bp.route("/mark-off", methods=["POST"])
@jwt_required()
def mark_employee_off():
    """Admin endpoint to mark pre-scheduled leave (OFF) for an employee on a specific date."""
    claims = get_jwt()
    role = claims.get("role")
    if role not in ["ParlourAdmin", "BranchAdmin", "SuperAdmin"]:
        return jsonify({"status": "error", "message": "Unauthorized"}), 403

    tenant_id = claims.get("parlour_id") or claims.get("tenant_id")
    data = request.get_json() or {}
    employee_id = data.get("employee_id")
    date_str = data.get("date")

    if not employee_id or not date_str:
        return jsonify({"status": "error", "message": "employee_id and date (YYYY-MM-DD) are required"}), 400

    try:
        target_date = datetime.strptime(date_str, "%Y-%m-%d").date()
    except ValueError:
        return jsonify({"status": "error", "message": "Invalid date format. Use YYYY-MM-DD"}), 400

    employee = Employee.query.get(employee_id)
    if not employee:
        return jsonify({"status": "error", "message": "Employee not found"}), 404

    branch_id = employee.branch_id or getattr(g, "branch_id", 1)

    start_dt = datetime.combine(target_date, datetime.min.time())
    end_dt = datetime.combine(target_date, datetime.max.time())

    existing = Attendance.query.filter_by(
        employee_id=employee_id
    ).filter(Attendance.timestamp >= start_dt, Attendance.timestamp <= end_dt).first()

    if existing:
        existing.status = "OFF"
    else:
        existing = Attendance(
            tenant_id=tenant_id or 1,
            employee_id=employee_id,
            branch_id=branch_id or 1,
            timestamp=start_dt,
            checkin_method="Manual",
            status="OFF"
        )
        db.session.add(existing)

    db.session.commit()
    return jsonify({"status": "success", "message": f"Marked {employee.first_name} as OFF for {date_str}"})


@attendance_bp.route("/manual-checkin", methods=["POST"])
@require_role(["ParlourAdmin", "BranchAdmin", "SuperAdmin", "Receptionist", "Employee"])
def manual_attendance_checkin():
    """Manual Front-Desk Fallback check-in endpoint (for Admins / Receptionists)."""
    claims = get_jwt()
    role = claims.get("role")
    if role not in ["ParlourAdmin", "BranchAdmin", "SuperAdmin", "Receptionist", "Employee"]:
        return jsonify({"status": "error", "message": "Unauthorized"}), 403

    tenant_id = claims.get("parlour_id") or claims.get("tenant_id")
    data = request.get_json() or {}

    action_type = (data.get("action_type") or data.get("action") or "checkin").lower()
    employee_id = data.get("employee_id")
    branch_id = data.get("branch_id")
    reason = (data.get("reason") or "Manual Front-Desk Fallback").strip()
    status_type = (data.get("status") or "P").upper()

    if not employee_id:
        return jsonify({"status": "error", "message": "Select an employee to submit manual attendance"}), 400

    try:
        employee_id = int(employee_id)
    except (ValueError, TypeError):
        return jsonify({"status": "error", "message": "Invalid employee ID"}), 400

    employee = Employee.query.get(employee_id)
    if not employee:
        return jsonify({"status": "error", "message": "Selected employee not found"}), 404

    target_branch_id = getattr(g, "branch_id", None) or branch_id or employee.branch_id or 1
    branch = Branch.query.get(target_branch_id)
    branch_name = branch.name if branch else "Main Branch"

    today_curr = get_ist_today()
    today_start = datetime.combine(today_curr, datetime.min.time())
    today_end = datetime.combine(today_curr, datetime.max.time())

    # Check any attendance today for this employee across branch or tenant
    existing = Attendance.query.filter_by(
        employee_id=employee.id
    ).filter(Attendance.timestamp >= today_start, Attendance.timestamp <= today_end).order_by(Attendance.timestamp.desc()).first()

    now = get_ist_now()

    if action_type == "checkin":
        if existing:
            # If same status already recorded (and already Present/Half Day), inform user
            if existing.status == status_type and existing.status in ["P", "HP"]:
                cin_time = existing.timestamp.strftime("%I:%M %p")
                return jsonify({
                    "status": "error",
                    "message": f"This employee is already marked as Present today at {cin_time}."
                }), 400

            # Override/update existing status (e.g. from Leave/Off to Present, or from HP to Present)
            existing.status = status_type if status_type in ["P", "HP", "OFF", "L"] else "P"
            existing.branch_id = target_branch_id
            existing.checkin_method = "Manual"
            existing.timestamp = now
            db.session.commit()

            cin_time = now.strftime("%I:%M %p")
            status_label = "Present" if existing.status == "P" else ("Half Day" if existing.status == "HP" else ("Leave" if existing.status == "L" else "Day Off"))
            return jsonify({
                "status": "success",
                "action": "checkin",
                "message": f"✅ Attendance updated to {status_label} for {employee.first_name} {employee.last_name or ''} at {cin_time} ({branch_name}).",
                "data": {
                    "id": existing.id,
                    "employee_name": f"{employee.first_name} {employee.last_name or ''}".strip(),
                    "checkin_time": cin_time,
                    "status": existing.status
                }
            }), 200

        # Create new Manual Check-in
        attendance = Attendance(
            tenant_id=tenant_id or employee.tenant_id or 1,
            employee_id=employee.id,
            branch_id=target_branch_id,
            timestamp=now,
            checkin_method="Manual",
            location_flagged=False,
            location_unavailable=True,
            status=status_type if status_type in ["P", "HP", "OFF", "L"] else "P"
        )
        db.session.add(attendance)
        db.session.commit()

        cin_time = now.strftime("%I:%M %p")
        status_label = "Present" if attendance.status == "P" else ("Half Day" if attendance.status == "HP" else ("Leave" if attendance.status == "L" else "Day Off"))
        return jsonify({
            "status": "success",
            "action": "checkin",
            "message": f"✅ Manual check-in ({status_label}) submitted for {employee.first_name} {employee.last_name or ''} at {cin_time} ({branch_name}). Audit Reason: {reason}",
            "data": {
                "id": attendance.id,
                "employee_name": f"{employee.first_name} {employee.last_name or ''}".strip(),
                "checkin_time": cin_time,
                "status": attendance.status
            }
        }), 201

    elif action_type == "checkout":
        if not existing:
            return jsonify({
                "status": "error",
                "message": "This employee has not checked in today yet."
            }), 400

        if existing.check_out_time:
            cout_time = existing.check_out_time.strftime("%I:%M %p")
            return jsonify({
                "status": "error",
                "message": f"This employee already checked out today at {cout_time}."
            }), 400

        # Perform Manual Check-out
        existing.check_out_time = now
        existing.status = status_type if status_type in ["P", "HP", "OFF"] else "P"
        db.session.commit()

        cout_time = now.strftime("%I:%M %p")
        return jsonify({
            "status": "success",
            "action": "checkout",
            "message": f"✅ Manual check-out recorded for {employee.first_name} {employee.last_name or ''} at {cout_time}. Audit Reason: {reason}",
            "data": {
                "id": existing.id,
                "employee_name": f"{employee.first_name} {employee.last_name or ''}".strip(),
                "checkout_time": cout_time,
                "status": existing.status
            }
        }), 200

    else:
        return jsonify({"status": "error", "message": "Invalid action_type. Must be 'checkin' or 'checkout'."}), 400


