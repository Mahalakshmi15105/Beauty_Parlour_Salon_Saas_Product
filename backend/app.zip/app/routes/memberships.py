from flask import Blueprint, request, g
import json
from app.database import db
from app.models.membership import MembershipPlan, CustomerMembership, MembershipBenefit, MembershipPlanService
from app.models.global_models import Tenant
from app.models.catalog import Service
from app.models.customer import Customer
from app.utils.responses import success_response, error_response
from app.utils.auth import require_role, get_tenant_query, get_branch_query
from app.utils.query import paginate_query, generate_unique_invoice_number
from datetime import datetime, timedelta
from decimal import Decimal
import logging

logger = logging.getLogger(__name__)
memberships_bp = Blueprint("memberships", __name__)

def safe_json_parse(val):
    if not val:
        return []
    if isinstance(val, (list, dict)):
        return val
    try:
        return json.loads(val)
    except Exception:
        return []

from app.services.cache import cache

# --- MEMBERSHIP PLANS CRUD ---

@memberships_bp.route("/membership-plans", methods=["GET"])
@require_role(["ParlourAdmin", "BranchAdmin"])
def get_plans():
    q = request.args.get("q", "").strip()
    status = request.args.get("status", "").strip()
    limit = request.args.get("limit", 20)
    cursor = request.args.get("cursor")
    sort = request.args.get("sort", "name")

    # 0. Check Redis cache first
    cache_key = f"membershipplans:{g.parlour_id}:{q}:{status}:{limit}:{cursor}:{sort}"
    try:
        cached_data = cache.get(cache_key)
        if cached_data is not None:
            return success_response(cached_data)
    except Exception as c_err:
        logger.debug(f"Cache get error: {c_err}")

    try:
        query = get_branch_query(MembershipPlan)

        if q:
            query = query.filter(
                (MembershipPlan.name.ilike(f"%{q}%")) |
                (MembershipPlan.description.ilike(f"%{q}%"))
            )

        if status:
            query = query.filter(MembershipPlan.status == status)

        sort_field = "id"
        sort_desc = False
        if sort.startswith("-"):
            sort_field = sort[1:]
            sort_desc = True
        else:
            sort_field = sort

        plans, next_cursor = paginate_query(
            query=query,
            model=MembershipPlan,
            limit_val=limit,
            cursor=cursor,
            sort_field=sort_field,
            sort_desc=sort_desc
        )

        data = []
        for p in (plans or []):
            el_services = []
            try:
                if getattr(p, "eligible_services", None):
                    el_services = [es.service_id for es in p.eligible_services if hasattr(es, "service_id")]
            except Exception:
                el_services = []

            data.append({
                "id": p.id,
                "name": p.name or "",
                "description": p.description or "",
                "price": float(p.price or 0.0),
                "duration_days": p.duration_days or 0,
                "service_discount_percentage": float(p.service_discount_percentage or 0.0),
                "status": p.status or "active",
                "day_restrictions": safe_json_parse(p.day_restrictions),
                "eligible_services": el_services,
                "created_at": p.created_at.isoformat() if p.created_at else ""
            })

        result_payload = {
            "items": data,
            "next_cursor": next_cursor
        }

        try:
            cache.set(cache_key, result_payload, timeout=120)
        except Exception:
            pass

        return success_response(result_payload)
    except Exception as plan_err:
        logger.warning(f"Membership plans query fallback: {plan_err}")
        return success_response({
            "items": [],
            "next_cursor": None
        })


@memberships_bp.route("/membership-plans/<int:plan_id>", methods=["GET"])
@require_role(["ParlourAdmin", "BranchAdmin"])
def get_plan(plan_id):
    plan = get_tenant_query(MembershipPlan).filter_by(id=plan_id).first()
    if not plan:
        return error_response(
            error_code="PLAN_NOT_FOUND",
            message="Membership Plan not found or access denied.",
            status_code=404
        )
    return success_response({
        "id": plan.id,
        "name": plan.name or "",
        "description": plan.description or "",
        "price": float(plan.price or 0.0),
        "duration_days": plan.duration_days or 0,
        "service_discount_percentage": float(plan.service_discount_percentage or 0.0),
        "status": plan.status or "active",
        "day_restrictions": safe_json_parse(plan.day_restrictions),
        "eligible_services": [es.service_id for es in plan.eligible_services] if plan.eligible_services else []
    })


@memberships_bp.route("/membership-plans", methods=["POST"])
@require_role(["ParlourAdmin", "BranchAdmin"])
def create_plan():
    # Ensure tenant context is available
    if not getattr(g, 'parlour_id', None):
        return error_response(
            error_code="TENANT_CONTEXT_MISSING",
            message="Parlour tenant context is missing. Please login again.",
            status_code=400
        )
    data = request.get_json() or {}
    name = data.get("name", "").strip()
    price = data.get("price", 0.00)
    duration = data.get("duration_days", 365)
    svc_disc = data.get("service_discount_percentage", 0.00)

    if not name:
        return error_response(
            error_code="VALIDATION_FAILED",
            message="Plan Name is required.",
            status_code=400
        )

    try:
        price_val = float(price)
        dur_val = int(duration)
        svc_disc_val = float(svc_disc)
        if price_val < 0 or dur_val <= 0 or svc_disc_val < 0:
            raise ValueError()
    except ValueError:
        return error_response(
            error_code="VALIDATION_FAILED",
            message="Numeric settings (price, duration, discounts) must be positive values.",
            status_code=400
        )

    # Check duplicates in tenant context
    dup = get_branch_query(MembershipPlan).filter_by(name=name).first()
    if dup:
        return error_response(
            error_code="DUPLICATE_RECORD",
            message=f"A membership plan named '{name}' already exists.",
            status_code=400
        )

    day_restrictions = data.get("day_restrictions", [])
    eligible_services_ids = data.get("eligible_services", [])

    target_branch_id = g.branch_id if (hasattr(g, "branch_id") and g.branch_id) else (int(data["branch_id"]) if data.get("branch_id") else None)

    try:
        plan = MembershipPlan(
            tenant_id=g.parlour_id,
            branch_id=target_branch_id,
            name=name,
            description=data.get("description"),
            price=price_val,
            duration_days=dur_val,
            service_discount_percentage=svc_disc_val,
            product_discount_percentage=0.00,
            status=data.get("status", "active"),
            day_restrictions=json.dumps(day_restrictions) if day_restrictions else None
        )
        db.session.add(plan)
        db.session.flush() # Fetch plan.id for junction mapping

        for svc_id in eligible_services_ids:
            mapping = MembershipPlanService(
                tenant_id=g.parlour_id,
                membership_plan_id=plan.id,
                service_id=int(svc_id)
            )
            db.session.add(mapping)

        db.session.commit()
        try:
            cache.delete_pattern(f"membershipplans:{g.parlour_id}:*")
        except Exception:
            pass
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error creating plan: {str(e)}")
        return error_response(
            error_code="DATABASE_ERROR",
            message=f"Failed to create plan: {str(e)}",
            status_code=500
        )

    return success_response({"id": plan.id, "name": plan.name}, 201)


@memberships_bp.route("/membership-plans/<int:plan_id>", methods=["PUT"])
@require_role(["ParlourAdmin", "BranchAdmin"])
def update_plan(plan_id):
    plan = get_tenant_query(MembershipPlan).filter_by(id=plan_id).first()
    if not plan:
        return error_response(
            error_code="PLAN_NOT_FOUND",
            message="Membership Plan not found or access denied.",
            status_code=404
        )

    # Ensure tenant context is available
    if not getattr(g, 'parlour_id', None):
        return error_response(
            error_code="TENANT_CONTEXT_MISSING",
            message="Parlour tenant context is missing. Please login again.",
            status_code=400
        )
    data = request.get_json() or {}
    name = data.get("name", "").strip()
    price = data.get("price", 0.00)
    duration = data.get("duration_days", 365)
    svc_disc = data.get("service_discount_percentage", 0.00)

    if not name:
        return error_response(
            error_code="VALIDATION_FAILED",
            message="Plan Name is required.",
            status_code=400
        )

    try:
        price_val = float(price)
        dur_val = int(duration)
        svc_disc_val = float(svc_disc)
        if price_val < 0 or dur_val <= 0 or svc_disc_val < 0:
            raise ValueError()
    except ValueError:
        return error_response(
            error_code="VALIDATION_FAILED",
            message="Numeric settings (price, duration, discounts) must be positive values.",
            status_code=400
        )

    # Check duplicates
    dup = get_tenant_query(MembershipPlan).filter(MembershipPlan.name == name, MembershipPlan.id != plan_id).first()
    if dup:
        return error_response(
            error_code="DUPLICATE_RECORD",
            message=f"Another membership plan named '{name}' already exists.",
            status_code=400
        )

    day_restrictions = data.get("day_restrictions", [])
    eligible_services_ids = data.get("eligible_services", [])

    try:
        plan.name = name
        plan.description = data.get("description")
        plan.price = price_val
        plan.duration_days = dur_val
        plan.service_discount_percentage = svc_disc_val
        plan.product_discount_percentage = 0.00
        plan.status = data.get("status", "active")
        plan.day_restrictions = json.dumps(day_restrictions) if day_restrictions else None

        # Sync eligible services junction mapping
        MembershipPlanService.query.filter_by(membership_plan_id=plan.id).delete()
        for svc_id in eligible_services_ids:
            mapping = MembershipPlanService(
                tenant_id=g.parlour_id,
                membership_plan_id=plan.id,
                service_id=int(svc_id)
            )
            db.session.add(mapping)

        db.session.commit()
        try:
            cache.delete_pattern(f"membershipplans:{g.parlour_id}:*")
        except Exception:
            pass
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error updating plan: {str(e)}")
        return error_response(
            error_code="DATABASE_ERROR",
            message=f"Failed to update plan: {str(e)}",
            status_code=500
        )

    return success_response({"message": "Plan updated successfully."})


@memberships_bp.route("/membership-plans/<int:plan_id>", methods=["DELETE"])
@require_role(["ParlourAdmin", "BranchAdmin"])
def delete_plan(plan_id):
    plan = get_tenant_query(MembershipPlan).filter_by(id=plan_id).first()
    if not plan:
        return error_response(
            error_code="PLAN_NOT_FOUND",
            message="Membership Plan not found or access denied.",
            status_code=404
        )

    try:
        plan.soft_delete()
        db.session.commit()
        try:
            cache.delete_pattern(f"membershipplans:{g.parlour_id}:*")
        except Exception:
            pass
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error deleting plan: {str(e)}")
        return error_response(
            error_code="DATABASE_ERROR",
            message="Failed to delete plan.",
            status_code=500
        )

    return success_response({"message": "Membership plan soft-deleted successfully."})


# --- CUSTOMER MEMBERSHIP ACTIONS ---

@memberships_bp.route("/memberships/assign", methods=["POST"])
@require_role(["ParlourAdmin", "BranchAdmin"])
def assign_membership():
    from app.models.billing import Invoice, InvoiceLineItem, InvoicePayment
    from app.models.user import TenantSetting

    data = request.get_json() or {}
    customer_id = data.get("customer_id")
    plan_id = data.get("plan_id")
    is_existing_plan = bool(data.get("is_existing_plan", False))
    payment_method = data.get("payment_method", "Cash").strip() if data.get("payment_method") else ("Already Paid (Offline)" if is_existing_plan else "Cash")
    benefits_data = data.get("benefits", [])  # list of {service_id, total_quantity / quantity, remaining_quantity}

    if not customer_id or not plan_id:
        return error_response(
            error_code="VALIDATION_FAILED",
            message="Customer ID and Plan ID are required.",
            status_code=400
        )

    # Verify customer and plan across tenant context
    customer = Customer.query.filter_by(id=customer_id, tenant_id=g.parlour_id, is_deleted=False).first()
    plan = MembershipPlan.query.filter_by(id=plan_id, tenant_id=g.parlour_id, is_deleted=False).first()

    if not customer or not plan:
        return error_response(
            error_code="VALIDATION_FAILED",
            message="Selected customer or active plan does not exist.",
            status_code=400
        )

    # Parse custom start date
    custom_start_date_str = data.get("start_date")
    start_date = datetime.now()
    if custom_start_date_str:
        try:
            if "T" in str(custom_start_date_str):
                start_date = datetime.fromisoformat(str(custom_start_date_str).replace("Z", "+00:00"))
            else:
                start_date = datetime.strptime(str(custom_start_date_str)[:10], "%Y-%m-%d")
        except Exception:
            start_date = datetime.now()

    # Parse custom expiry date or compute from duration
    custom_expires_at_str = data.get("expires_at")
    expiry_date = None
    if custom_expires_at_str:
        try:
            if "T" in str(custom_expires_at_str):
                expiry_date = datetime.fromisoformat(str(custom_expires_at_str).replace("Z", "+00:00"))
            else:
                expiry_date = datetime.strptime(str(custom_expires_at_str)[:10], "%Y-%m-%d").replace(hour=23, minute=59, second=59)
        except Exception:
            expiry_date = None

    if not expiry_date:
        days = getattr(plan, 'duration_days', None)
        if not days or days <= 0:
            duration_cnt = getattr(plan, 'duration_count', 1) or 1
            validity_p = getattr(plan, 'validity_plan', 'Yearly') or 'Yearly'
            if str(validity_p).lower() == 'monthly':
                days = duration_cnt * 30
            else:
                days = duration_cnt * 365
        expiry_date = start_date + timedelta(days=days)

    # Initial status depending on expiry date
    initial_status = "active"
    if expiry_date < datetime.now():
        initial_status = "expired"

    # Calculate Invoice Prices & Tax
    target_branch_id = g.branch_id if hasattr(g, "branch_id") and g.branch_id else None
    if not target_branch_id and customer.branch_id:
        target_branch_id = customer.branch_id

    plan_price = Decimal(str(getattr(plan, 'price', 0.00) or 0.00))
    
    settings = TenantSetting.query.filter_by(tenant_id=g.parlour_id, branch_id=target_branch_id).first()
    if not settings:
        settings = TenantSetting.query.filter_by(tenant_id=g.parlour_id, branch_id=None).first()
    
    enable_tax = bool(getattr(settings, "enable_membership_tax", False))
    tax_rate = Decimal(str(settings.tax_rate)) if (settings and settings.tax_rate and enable_tax) else Decimal("0.00")
    calculated_tax = round(plan_price * (tax_rate / Decimal("100.00")), 2) if tax_rate > 0 else Decimal("0.00")
    grand_total = plan_price + calculated_tax

    try:
        # 1. Generate Invoice Number & Invoice Record
        invoice_number = generate_unique_invoice_number(g.parlour_id, target_branch_id)
        membership_label = f"{plan.name} (Existing/Offline Plan)" if is_existing_plan else plan.name

        invoice = Invoice(
            tenant_id=g.parlour_id,
            branch_id=target_branch_id,
            invoice_number=invoice_number,
            customer_id=customer_id,
            subtotal=plan_price,
            discount=Decimal("0.00"),
            tax=calculated_tax,
            total=grand_total,
            status="Paid",
            membership_name=membership_label,
            membership_discount=Decimal("0.00"),
            created_at=start_date
        )
        db.session.add(invoice)
        db.session.flush()

        # Save Line Item
        line_item = InvoiceLineItem(
            tenant_id=g.parlour_id,
            branch_id=target_branch_id,
            invoice_id=invoice.id,
            quantity=1,
            unit_price=plan_price,
            discount_amount=Decimal("0.00"),
            tax_amount=calculated_tax,
            line_total=grand_total,
            created_at=start_date
        )
        db.session.add(line_item)

        # Save Payment
        payment = InvoicePayment(
            tenant_id=g.parlour_id,
            invoice_id=invoice.id,
            method=payment_method,
            amount=grand_total,
            created_at=start_date
        )
        db.session.add(payment)

        # 2. Create Membership linkage
        cm = CustomerMembership(
            tenant_id=g.parlour_id,
            branch_id=target_branch_id,
            customer_id=customer_id,
            membership_plan_id=plan_id,
            expires_at=expiry_date,
            status=initial_status,
            created_at=start_date
        )
        db.session.add(cm)
        db.session.flush()

        # Add benefits
        for b in benefits_data:
            svc_id = b.get("service_id")
            total_qty = int(b.get("total_quantity") or b.get("quantity") or 1)
            rem_qty_raw = b.get("remaining_quantity")
            rem_qty = int(rem_qty_raw) if rem_qty_raw is not None else total_qty
            if not svc_id or total_qty <= 0:
                continue
            
            svc = Service.query.filter_by(id=svc_id, tenant_id=g.parlour_id).first()
            if not svc:
                raise ValueError(f"Service ID {svc_id} is invalid.")

            benefit = MembershipBenefit(
                tenant_id=g.parlour_id,
                branch_id=target_branch_id,
                customer_membership_id=cm.id,
                service_id=svc_id,
                total_quantity=total_qty,
                remaining_quantity=max(0, min(rem_qty, total_qty))
            )
            db.session.add(benefit)

        db.session.commit()
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error assigning membership: {str(e)}")
        return error_response(
            error_code="TRANSACTION_FAILED",
            message=str(e) if isinstance(e, ValueError) else f"Failed to assign membership: {str(e)}",
            status_code=400 if isinstance(e, ValueError) else 500
        )

    return success_response({
        "membership_id": cm.id, 
        "invoice_id": invoice.id,
        "expires_at": cm.expires_at.isoformat(),
        "invoice_number": invoice.invoice_number,
        "total_amount": float(grand_total),
        "is_existing_plan": is_existing_plan
    }, 201)


@memberships_bp.route("/memberships/customer/<int:customer_id>", methods=["GET"])
@require_role(["ParlourAdmin", "BranchAdmin"])
def get_customer_memberships_alias(customer_id):
    customer = Customer.query.filter_by(id=customer_id, tenant_id=g.parlour_id, is_deleted=False).first()
    if not customer:
        return error_response(
            error_code="CUSTOMER_NOT_FOUND",
            message="Customer not found.",
            status_code=404
        )

    memberships = CustomerMembership.query.filter_by(
        customer_id=customer_id,
        tenant_id=g.parlour_id
    ).order_by(CustomerMembership.id.desc()).all()

    data = []
    for m in memberships:
        benefits = []
        for b in m.benefits:
            benefits.append({
                "id": b.id,
                "service_id": b.service_id,
                "service_name": b.service.name if b.service else None,
                "total_quantity": b.total_quantity,
                "remaining_quantity": b.remaining_quantity
            })
        
        data.append({
            "id": m.id,
            "plan_id": m.membership_plan_id,
            "plan_name": m.plan.name if m.plan else "Default Membership",
            "price": float(m.plan.price) if m.plan and m.plan.price else 0.0,
            "start_date": m.created_at.isoformat() if m.created_at else None,
            "expires_at": m.expires_at.isoformat(),
            "status": m.status,
            "renew_count": getattr(m, 'renew_count', 0) or 0,
            "benefits": benefits
        })

    return success_response(data)



@memberships_bp.route("/memberships/<int:cm_id>/renew", methods=["POST"])
@require_role(["ParlourAdmin", "BranchAdmin"])
def renew_membership(cm_id):
    from app.models.billing import Invoice, InvoiceLineItem, InvoicePayment
    from app.models.user import TenantSetting

    data = request.get_json() or {}
    payment_method = data.get("payment_method", "Cash").strip() if data.get("payment_method") else "Cash"

    cm = CustomerMembership.query.filter_by(id=cm_id, tenant_id=g.parlour_id).first()
    if not cm:
        return error_response(
            error_code="MEMBERSHIP_NOT_FOUND",
            message="Membership record not found.",
            status_code=404
        )

    plan = get_tenant_query(MembershipPlan).filter_by(id=cm.membership_plan_id).first()
    if not plan:
        raise ValueError("Membership Plan associated is invalid.")

    customer = Customer.query.filter_by(id=cm.customer_id, tenant_id=g.parlour_id).first()

    target_branch_id = g.branch_id if hasattr(g, "branch_id") and g.branch_id else None
    if not target_branch_id and customer and customer.branch_id:
        target_branch_id = customer.branch_id

    plan_price = Decimal(str(getattr(plan, 'price', 0.00) or 0.00))
    
    settings = TenantSetting.query.filter_by(tenant_id=g.parlour_id, branch_id=target_branch_id).first()
    if not settings:
        settings = TenantSetting.query.filter_by(tenant_id=g.parlour_id, branch_id=None).first()

    tax_rate = Decimal(str(settings.tax_rate)) if settings and settings.tax_rate else Decimal("0.00")
    calculated_tax = round(plan_price * (tax_rate / Decimal("100.00")), 2) if tax_rate > 0 else Decimal("0.00")
    grand_total = plan_price + calculated_tax

    try:
        # Create Renewal Invoice
        invoice_number = generate_unique_invoice_number(g.parlour_id, target_branch_id)

        invoice = Invoice(
            tenant_id=g.parlour_id,
            branch_id=target_branch_id,
            invoice_number=invoice_number,
            customer_id=cm.customer_id,
            subtotal=plan_price,
            discount=Decimal("0.00"),
            tax=calculated_tax,
            total=grand_total,
            status="Paid",
            membership_name=f"{plan.name} (Renewal)",
            membership_discount=Decimal("0.00")
        )
        db.session.add(invoice)
        db.session.flush()

        # Save Line Item
        line_item = InvoiceLineItem(
            tenant_id=g.parlour_id,
            branch_id=target_branch_id,
            invoice_id=invoice.id,
            quantity=1,
            unit_price=plan_price,
            discount_amount=Decimal("0.00"),
            tax_amount=calculated_tax,
            line_total=grand_total
        )
        db.session.add(line_item)

        # Save Payment
        payment = InvoicePayment(
            tenant_id=g.parlour_id,
            invoice_id=invoice.id,
            method=payment_method,
            amount=grand_total
        )
        db.session.add(payment)

        # Extend expiration & increment renewal count
        base_date = max(datetime.now(), cm.expires_at)
        cm.expires_at = base_date + timedelta(days=plan.duration_days)
        cm.status = "active"
        cm.renew_count = (getattr(cm, 'renew_count', 0) or 0) + 1

        # Reset benefits
        for b in cm.benefits:
            b.remaining_quantity = b.total_quantity
            
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error renewing membership: {str(e)}")
        return error_response(
            error_code="DATABASE_ERROR",
            message="Failed to renew membership.",
            status_code=500
        )

    return success_response({
        "message": "Membership renewed successfully.", 
        "new_expiry": cm.expires_at.isoformat(),
        "invoice_id": invoice.id,
        "invoice_number": invoice.invoice_number,
        "total_amount": float(grand_total)
    })


@memberships_bp.route("/memberships/<int:cm_id>/upgrade", methods=["POST"])
@require_role(["ParlourAdmin", "BranchAdmin"])
def upgrade_membership(cm_id):
    cm = CustomerMembership.query.filter_by(id=cm_id, tenant_id=g.parlour_id).first()
    if not cm:
        return error_response(
            error_code="MEMBERSHIP_NOT_FOUND",
            message="Membership record not found.",
            status_code=404
        )

    data = request.get_json() or {}
    new_plan_id = data.get("plan_id")
    benefits_data = data.get("benefits", [])

    new_plan = get_tenant_query(MembershipPlan).filter_by(id=new_plan_id, status="active").first()
    if not new_plan:
        return error_response(
            error_code="PLAN_NOT_FOUND",
            message="Upgrade plan does not exist or is inactive.",
            status_code=400
        )

    try:
        # 1. Cancel old membership
        cm.status = "cancelled"  # mark upgraded as cancelled/upgraded audit state
        
        # 2. Assign new membership
        expiry_date = datetime.now() + timedelta(days=new_plan.duration_days)
        new_cm = CustomerMembership(
            tenant_id=g.parlour_id,
            customer_id=cm.customer_id,
            membership_plan_id=new_plan_id,
            expires_at=expiry_date,
            status="active"
        )
        db.session.add(new_cm)
        db.session.flush()

        # Add new benefits
        for b in benefits_data:
            svc_id = b.get("service_id")
            qty = int(b.get("quantity", 1))
            if not svc_id or qty <= 0:
                continue

            benefit = MembershipBenefit(
                tenant_id=g.parlour_id,
                customer_membership_id=new_cm.id,
                service_id=svc_id,
                total_quantity=qty,
                remaining_quantity=qty
            )
            db.session.add(benefit)

        db.session.commit()
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error upgrading membership: {str(e)}")
        return error_response(
            error_code="TRANSACTION_FAILED",
            message="Failed to upgrade membership.",
            status_code=500
        )

    return success_response({"membership_id": new_cm.id, "new_plan_name": new_plan.name})


@memberships_bp.route("/memberships/<int:cm_id>/cancel", methods=["POST"])
@require_role(["ParlourAdmin", "BranchAdmin"])
def cancel_membership(cm_id):
    cm = CustomerMembership.query.filter_by(id=cm_id, tenant_id=g.parlour_id).first()
    if not cm:
        return error_response(
            error_code="MEMBERSHIP_NOT_FOUND",
            message="Membership record not found.",
            status_code=404
        )

    try:
        cm.status = "cancelled"
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error cancelling membership: {str(e)}")
        return error_response(
            error_code="DATABASE_ERROR",
            message="Failed to cancel membership.",
            status_code=500
        )

    return success_response({"message": "Membership cancelled successfully."})


@memberships_bp.route("/memberships", methods=["GET"])
@require_role(["ParlourAdmin", "BranchAdmin"])
def get_all_memberships():
    from app.models.customer import Customer
    query = CustomerMembership.query.join(Customer).filter(CustomerMembership.tenant_id == g.parlour_id)
    
    target_bid = getattr(g, "branch_id", None)
    if not target_bid:
        b_param = request.args.get("branch_id")
        if b_param and b_param not in ("all", "main", "null", "0", "None"):
            try:
                target_bid = int(b_param)
            except (ValueError, TypeError):
                pass

    main_b_id = None
    try:
        from app.models.branch import Branch
        main_b = Branch.query.filter_by(is_main_branch=True, is_deleted=False).first()
        if not main_b:
            main_b = Branch.query.filter_by(is_deleted=False).first()
        if main_b:
            main_b_id = main_b.id
    except Exception:
        main_b_id = 1

    if not target_bid:
        target_bid = main_b_id or 1

    if target_bid == main_b_id:
        query = query.filter(
            (Customer.branch_id == target_bid) | (Customer.branch_id.is_(None)) |
            (CustomerMembership.branch_id == target_bid) | (CustomerMembership.branch_id.is_(None))
        )
    else:
        query = query.filter(
            (Customer.branch_id == target_bid) | (CustomerMembership.branch_id == target_bid)
        )

    query = query.order_by(CustomerMembership.id.desc())
    
    results = []
    for cm in query.all():
        benefits = []
        for b in cm.benefits:
            benefits.append({
                "id": b.id,
                "service_id": b.service_id,
                "service_name": b.service.name if b.service else None,
                "total_quantity": b.total_quantity,
                "remaining_quantity": b.remaining_quantity
            })
            
        from app.models.billing import Invoice
        inv = Invoice.query.filter(
            Invoice.customer_id == cm.customer_id,
            Invoice.tenant_id == g.parlour_id,
            (Invoice.membership_name == cm.plan.name) | (Invoice.membership_name.ilike(f"%{cm.plan.name}%")) if cm.plan else False
        ).order_by(Invoice.id.desc()).first()

        results.append({
            "id": cm.id,
            "customer_id": cm.customer_id,
            "customer_name": f"{cm.customer.first_name} {cm.customer.last_name or ''}".strip() if cm.customer else "Unknown Customer",
            "customer_phone": cm.customer.phone if cm.customer else "No Phone",
            "plan_id": cm.membership_plan_id,
            "plan_name": cm.plan.name if cm.plan else "Default Membership",
            "price": float(cm.plan.price) if cm.plan and cm.plan.price else 0.0,
            "start_date": cm.created_at.isoformat() if cm.created_at else None,
            "created_at": cm.created_at.isoformat() if cm.created_at else None,
            "expires_at": cm.expires_at.isoformat(),
            "status": cm.status,
            "renew_count": getattr(cm, "renew_count", 0) or 0,
            "invoice_id": inv.id if inv else None,
            "invoice_number": inv.invoice_number if inv else None,
            "invoice_total": float(inv.total) if inv else float(cm.plan.price) if cm.plan and cm.plan.price else 0.0,
            "invoice_date": inv.created_at.isoformat() if inv else (cm.created_at.isoformat() if cm.created_at else None),
            "benefits": benefits
        })
    return success_response(results)
