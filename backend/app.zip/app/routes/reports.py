from flask import Blueprint, request, g, Response
from app.database import db
from app.models.billing import Invoice, InvoiceLineItem, InvoicePayment
from app.models.catalog import Service, Product, StockReorderLog
from app.models.customer import Customer
from app.models.employee import Employee
from app.models.membership import CustomerMembership
from app.utils.responses import success_response, error_response
from app.utils.auth import require_role, get_tenant_query, get_branch_query
from sqlalchemy import func, cast, Date
from datetime import datetime, date, timedelta, timezone
from decimal import Decimal, ROUND_HALF_UP
import io
import csv
import logging
import calendar

logger = logging.getLogger(__name__)
reports_bp = Blueprint("reports", __name__)

REQUIRED_TABLE_COLUMNS = {
    "branches": ["id", "tenant_id", "name", "is_main_branch", "latitude", "longitude", "geofence_radius_meters", "initial_opening_balance"],
    "employees": ["id", "tenant_id", "first_name", "last_name", "phone", "salary", "target", "level", "commission_percentage", "status"],
    "attendances": ["id", "tenant_id", "employee_id", "branch_id", "timestamp", "status", "check_out_time"],
    "invoices": ["id", "tenant_id", "branch_id", "customer_id", "subtotal", "discount", "tax", "total", "status", "created_at"],
    "invoice_line_items": ["id", "invoice_id", "service_id", "product_id", "employee_id", "quantity", "unit_price", "tax_rate", "line_total"],
    "expenses": ["id", "tenant_id", "branch_id", "amount", "date", "note", "is_deleted"],
    "cash_denominations": ["id", "tenant_id", "branch_id", "date", "total"],
    "payroll_adjustments": ["id", "tenant_id", "employee_id", "type", "amount", "date"]
}

def parse_date_range(preset, start_str=None, end_str=None):
    now = datetime.now(timezone.utc)
    if preset == "today":
        start = datetime(now.year, now.month, now.day, tzinfo=timezone.utc)
        end = now
    elif preset == "yesterday":
        yest = now - timedelta(days=1)
        start = datetime(yest.year, yest.month, yest.day, tzinfo=timezone.utc)
        end = datetime(now.year, now.month, now.day, tzinfo=timezone.utc)
    elif preset == "7days":
        start = now - timedelta(days=7)
        end = now
    elif preset == "30days":
        start = now - timedelta(days=30)
        end = now
    elif preset == "this_month":
        start = datetime(now.year, now.month, 1, tzinfo=timezone.utc)
        end = now
    elif preset == "last_month":
        first_this = datetime(now.year, now.month, 1, tzinfo=timezone.utc)
        last_prev = first_this - timedelta(days=1)
        start = datetime(last_prev.year, last_prev.month, 1, tzinfo=timezone.utc)
        end = first_this
    elif preset == "custom" and start_str and end_str:
        try:
            start = datetime.strptime(start_str, "%Y-%m-%d").replace(tzinfo=timezone.utc)
            end = datetime.strptime(end_str, "%Y-%m-%d").replace(tzinfo=timezone.utc) + timedelta(days=1)
        except ValueError:
            start = now - timedelta(days=30)
            end = now
    else:
        start = now - timedelta(days=30)
        end = now
    return start, end


@reports_bp.route("/reports/system/schema-check", methods=["GET"])
def schema_check():
    """Deployment Safety Schema Audit Endpoint."""
    from sqlalchemy import inspect
    try:
        engine = db.get_tenant_engine(g.tenant_db_uri) if hasattr(g, "tenant_db_uri") and g.tenant_db_uri else db.engine
        inspector = inspect(engine)
        existing_tables = inspector.get_table_names()
        missing_details = []
        for tbl, cols in REQUIRED_TABLE_COLUMNS.items():
            if tbl not in existing_tables:
                missing_details.append(f"Table '{tbl}' missing")
            else:
                actual = [c["name"] for c in inspector.get_columns(tbl)]
                for c in cols:
                    if c not in actual:
                        missing_details.append(f"Column '{tbl}.{c}' missing")
        if missing_details:
            return error_response(f"Schema Check Failed: {', '.join(missing_details)}", 500)
        return success_response({"status": "healthy", "message": "All database tables & columns verified."})
    except Exception as e:
        return error_response(f"Schema check error: {str(e)}", 500)


@reports_bp.route("/reports/sales", methods=["GET"])
@require_role(["ParlourAdmin", "BranchAdmin"])
def get_sales_report():
    preset = request.args.get("preset", "30days")
    start_date, end_date = parse_date_range(preset, request.args.get("start_date"), request.args.get("end_date"))
    status_filter = request.args.get("status")

    query = get_branch_query(Invoice).filter(
        Invoice.created_at >= start_date,
        Invoice.created_at <= end_date
    )

    if status_filter:
        query = query.filter(Invoice.status == status_filter)

    invoices = query.order_by(Invoice.created_at.desc()).all()

    items = []
    total_sales = Decimal("0.00")
    total_tax = Decimal("0.00")
    total_discount = Decimal("0.00")

    for inv in invoices:
        if inv.status != "Voided":
            total_sales += inv.total
            total_tax += inv.tax
            total_discount += inv.discount

        cust_name = f"{inv.customer.first_name} {inv.customer.last_name or ''}".strip() if inv.customer else "Walk-In Client"
        items.append({
            "id": inv.id,
            "invoice_number": inv.invoice_number,
            "date": inv.created_at.strftime("%Y-%m-%d %H:%M"),
            "customer_name": cust_name,
            "subtotal": float(inv.subtotal),
            "discount": float(inv.discount),
            "tax": float(inv.tax),
            "total": float(inv.total),
            "status": inv.status
        })

    return success_response({
        "summary": {
            "total_sales": float(total_sales),
            "total_tax": float(total_tax),
            "total_discount": float(total_discount),
            "total_orders": len(invoices)
        },
        "items": items
    })


@reports_bp.route("/reports/tax", methods=["GET"])
@require_role(["ParlourAdmin", "BranchAdmin"])
def get_tax_report():
    preset = request.args.get("preset", "30days")
    start_date, end_date = parse_date_range(preset, request.args.get("start_date"), request.args.get("end_date"))

    tax_q = db.session.query(
        cast(Invoice.created_at, Date).label("date"),
        func.sum(Invoice.subtotal).label("gross_subtotal"),
        func.sum(Invoice.discount).label("discount"),
        func.sum(Invoice.tax).label("tax_collected"),
        func.sum(Invoice.total).label("net_total")
    ).filter(
        Invoice.tenant_id == g.parlour_id,
        Invoice.status != "Voided",
        Invoice.created_at >= start_date,
        Invoice.created_at <= end_date
    )
    if g.branch_id:
        tax_q = tax_q.filter(Invoice.branch_id == g.branch_id)
    tax_query = tax_q.group_by(cast(Invoice.created_at, Date)).order_by(cast(Invoice.created_at, Date).desc()).all()

    items = []
    total_tax_collected = Decimal("0.00")

    for row in tax_query:
        tax_val = row.tax_collected or Decimal("0.00")
        total_tax_collected += tax_val
        items.append({
            "date": row.date.strftime("%Y-%m-%d") if row.date else "",
            "gross_subtotal": float(row.gross_subtotal or 0.0),
            "discount": float(row.discount or 0.0),
            "tax_collected": float(tax_val),
            "net_total": float(row.net_total or 0.0)
        })

    return success_response({
        "total_tax_collected": float(total_tax_collected),
        "daily_tax_logs": items
    })


@reports_bp.route("/reports/employees", methods=["GET"])
@require_role(["ParlourAdmin", "BranchAdmin"])
def get_employee_report():
    preset = request.args.get("preset", "30days")
    start_date, end_date = parse_date_range(preset, request.args.get("start_date"), request.args.get("end_date"))

    emp_q = db.session.query(
        Employee.id,
        Employee.first_name,
        Employee.last_name,
        Employee.commission_percentage,
        func.count(InvoiceLineItem.id).label("services_rendered"),
        func.sum(InvoiceLineItem.line_total).label("total_revenue")
    ).join(InvoiceLineItem, Employee.id == InvoiceLineItem.employee_id).join(
        Invoice, InvoiceLineItem.invoice_id == Invoice.id
    ).filter(
        Invoice.tenant_id == g.parlour_id,
        Invoice.status != "Voided",
        Invoice.created_at >= start_date,
        Invoice.created_at <= end_date
    )
    if g.branch_id:
        emp_q = emp_q.filter(Invoice.branch_id == g.branch_id)
    query = emp_q.group_by(Employee.id, Employee.first_name, Employee.last_name, Employee.commission_percentage).all()

    items = []
    for row in query:
        rev = Decimal(str(row.total_revenue or 0.0))
        comm_pct = Decimal(str(row.commission_percentage or 0.0))
        comm_earned = rev * (comm_pct / Decimal("100.00"))

        items.append({
            "employee_id": row.id,
            "name": f"{row.first_name} {row.last_name or ''}".strip(),
            "commission_percentage": float(comm_pct),
            "services_rendered": row.services_rendered,
            "total_revenue": float(rev),
            "estimated_commission": float(comm_earned)
        })

    return success_response(items)


@reports_bp.route("/reports/products", methods=["GET"])
@require_role(["ParlourAdmin", "BranchAdmin"])
def get_product_report():
    prod_q = db.session.query(
        Product.id,
        Product.name,
        Product.sku,
        Product.stock_quantity,
        Product.selling_price,
        func.coalesce(func.sum(InvoiceLineItem.quantity), 0).label("units_sold"),
        func.coalesce(func.sum(InvoiceLineItem.line_total), Decimal("0.00")).label("total_sales")
    ).outerjoin(InvoiceLineItem, Product.id == InvoiceLineItem.product_id).filter(
        Product.tenant_id == g.parlour_id,
        Product.status == "active"
    )
    if g.branch_id:
        prod_q = prod_q.filter(Product.branch_id == g.branch_id)
    query = prod_q.group_by(Product.id, Product.name, Product.sku, Product.stock_quantity, Product.selling_price).all()

    items = []
    for row in query:
        items.append({
            "id": row.id,
            "name": row.name,
            "sku": row.sku,
            "stock_quantity": row.stock_quantity,
            "selling_price": float(row.selling_price),
            "units_sold": int(row.units_sold),
            "total_sales": float(row.total_sales)
        })

    return success_response(items)


@reports_bp.route("/reports/procurement", methods=["GET"])
@require_role(["ParlourAdmin", "BranchAdmin"])
def get_procurement_report():
    preset = request.args.get("preset", "30days")
    start_date, end_date = parse_date_range(preset, request.args.get("start_date"), request.args.get("end_date"))

    logs = get_branch_query(StockReorderLog).filter(
        StockReorderLog.created_at >= start_date,
        StockReorderLog.created_at <= end_date
    ).order_by(StockReorderLog.created_at.desc()).all()

    total_spent = Decimal("0.00")
    total_qty = 0
    items = []

    for log in logs:
        sub = log.cost_price * log.quantity
        total_spent += sub
        total_qty += log.quantity
        items.append({
            "id": log.id,
            "date": log.created_at.strftime("%Y-%m-%d %H:%M"),
            "product_name": log.product.name if log.product else "Deleted Product",
            "supplier_name": log.supplier.name if log.supplier else "N/A",
            "quantity": log.quantity,
            "cost_price": float(log.cost_price),
            "total_price": float(sub),
            "status": log.status
        })

    return success_response({
        "summary": {
            "total_spent": float(total_spent),
            "total_quantity": total_qty,
            "total_orders": len(logs)
        },
        "items": items
    })


@reports_bp.route("/reports/memberships", methods=["GET"])
@require_role(["ParlourAdmin", "BranchAdmin"])
def get_memberships_report():
    preset = request.args.get("preset", "30days")
    start_date, end_date = parse_date_range(preset, request.args.get("start_date"), request.args.get("end_date"))

    logs = get_branch_query(CustomerMembership).filter(
        CustomerMembership.created_at >= start_date,
        CustomerMembership.created_at <= end_date
    ).order_by(CustomerMembership.created_at.desc()).all()

    total_revenue = Decimal("0.00")
    items = []

    for cm in logs:
        plan_price = cm.plan.price if cm.plan else Decimal("0.00")
        if cm.status != "cancelled":
            total_revenue += plan_price
        cust_name = f"{cm.customer.first_name} {cm.customer.last_name or ''}".strip() if cm.customer else "Deleted Customer"
        items.append({
            "id": cm.id,
            "customer_name": cust_name,
            "plan_name": cm.plan.name if cm.plan else "Deleted Plan",
            "price": float(plan_price),
            "start_date": cm.created_at.strftime("%Y-%m-%d"),
            "end_date": cm.expires_at.strftime("%Y-%m-%d") if cm.expires_at else "—",
            "status": cm.status,
            "created_at": cm.created_at.strftime("%Y-%m-%d %H:%M")
        })

    return success_response({
        "summary": {
            "total_revenue": float(total_revenue),
            "total_sold": len(logs)
        },
        "items": items
    })


@reports_bp.route("/reports/export", methods=["GET"])
@require_role(["ParlourAdmin", "BranchAdmin"])
def export_csv_report():
    report_type = request.args.get("type", "sales")
    preset = request.args.get("preset", "30days")
    start_date, end_date = parse_date_range(preset, request.args.get("start_date"), request.args.get("end_date"))

    output = io.StringIO()
    writer = csv.writer(output)

    if report_type == "sales":
        writer.writerow(["Invoice Number", "Date", "Customer Name", "Subtotal (INR)", "Discount (INR)", "Tax (INR)", "Total (INR)", "Status"])
        invoices = get_branch_query(Invoice).filter(
            Invoice.created_at >= start_date,
            Invoice.created_at <= end_date
        ).order_by(Invoice.created_at.desc()).all()

        for inv in invoices:
            cust_name = f"{inv.customer.first_name} {inv.customer.last_name or ''}".strip() if inv.customer else "Walk-In"
            writer.writerow([
                inv.invoice_number,
                inv.created_at.strftime("%Y-%m-%d %H:%M"),
                cust_name,
                float(inv.subtotal),
                float(inv.discount),
                float(inv.tax),
                float(inv.total),
                inv.status
            ])

    elif report_type == "tax":
        writer.writerow(["Date", "Gross Subtotal (INR)", "Discounts (INR)", "Tax Collected (INR)", "Net Total (INR)"])
        tax_q = db.session.query(
            cast(Invoice.created_at, Date).label("date"),
            func.sum(Invoice.subtotal).label("gross_subtotal"),
            func.sum(Invoice.discount).label("discount"),
            func.sum(Invoice.tax).label("tax_collected"),
            func.sum(Invoice.total).label("net_total")
        ).filter(
            Invoice.tenant_id == g.parlour_id,
            Invoice.status != "Voided",
            Invoice.created_at >= start_date,
            Invoice.created_at <= end_date
        )
        if g.branch_id:
            tax_q = tax_q.filter(Invoice.branch_id == g.branch_id)
        tax_rows = tax_q.group_by(cast(Invoice.created_at, Date)).all()

        for row in tax_rows:
            writer.writerow([
                row.date.strftime("%Y-%m-%d") if row.date else "",
                float(row.gross_subtotal or 0.0),
                float(row.discount or 0.0),
                float(row.tax_collected or 0.0),
                float(row.net_total or 0.0)
            ])

    elif report_type == "employees":
        writer.writerow(["Employee Name", "Commission Rate (%)", "Services Rendered", "Total Revenue (INR)", "Estimated Commission (INR)"])
        emp_q = db.session.query(
            Employee.first_name,
            Employee.last_name,
            Employee.commission_percentage,
            func.count(InvoiceLineItem.id).label("services_rendered"),
            func.sum(InvoiceLineItem.line_total).label("total_revenue")
        ).join(InvoiceLineItem, Employee.id == InvoiceLineItem.employee_id).join(
            Invoice, InvoiceLineItem.invoice_id == Invoice.id
        ).filter(
            Invoice.tenant_id == g.parlour_id,
            Invoice.status != "Voided",
            Invoice.created_at >= start_date,
            Invoice.created_at <= end_date
        )
        if g.branch_id:
            emp_q = emp_q.filter(Invoice.branch_id == g.branch_id)
        emp_rows = emp_q.group_by(Employee.id, Employee.first_name, Employee.last_name, Employee.commission_percentage).all()

        for r in emp_rows:
            rev = Decimal(str(r.total_revenue or 0.0))
            comm_pct = Decimal(str(r.commission_percentage or 0.0))
            comm_earned = rev * (comm_pct / Decimal("100.00"))
            writer.writerow([
                f"{r.first_name} {r.last_name or ''}".strip(),
                float(comm_pct),
                r.services_rendered,
                float(rev),
                float(comm_earned)
            ])

    elif report_type == "products":
        writer.writerow(["Product Name", "SKU", "Stock Quantity", "Selling Price (INR)", "Units Sold", "Total Revenue (INR)"])
        prods = get_branch_query(Product).filter_by(status="active").all()
        for p in prods:
            writer.writerow([p.name, p.sku or "", p.stock_quantity, float(p.selling_price), 0, float(p.selling_price * p.stock_quantity)])

    csv_data = output.getvalue()
    filename = f"{report_type}_report_{datetime.now().strftime('%Y%m%d')}.csv"

    return Response(
        csv_data,
        mimetype="text/csv",
        headers={"Content-Disposition": f"attachment; filename={filename}"}
    )


@reports_bp.route("/reports/daily-sales-statement", methods=["GET"])
@require_role(["ParlourAdmin", "BranchAdmin", "Receptionist"])
def get_daily_sales_statement():
    date_str = request.args.get("date") or date.today().isoformat()
    tenant_id = getattr(g, "parlour_id", None) or getattr(g, "tenant_id", 1)
    branch_id = getattr(g, "branch_id", None) or request.args.get("branch_id", type=int) or 1

    try:
        target_date = datetime.strptime(date_str, "%Y-%m-%d").date()
    except ValueError:
        target_date = date.today()

    from app.models.branch import Branch
    from app.models.expense import Expense
    from app.models.cash_denomination import CashDenomination
    from app.models.user import TenantSetting
    from sqlalchemy import text

    parlour_name = "SALON"
    try:
        if tenant_id:
            with db.get_master_engine().connect() as conn:
                row = conn.execute(text("SELECT name FROM tenants WHERE id = :tid"), {"tid": tenant_id}).fetchone()
                if row and row[0]:
                    parlour_name = row[0]
    except Exception:
        pass

    branch = Branch.query.get(branch_id) if branch_id else None
    branch_name = branch.name if branch else "MAIN BRANCH"

    start_dt = datetime.combine(target_date, datetime.min.time())
    end_dt = datetime.combine(target_date, datetime.max.time())

    invoices = get_branch_query(Invoice).filter(
        Invoice.created_at >= start_dt,
        Invoice.created_at <= end_dt,
        Invoice.status != "Voided"
    ).all()

    t_setting = TenantSetting.query.filter_by(tenant_id=tenant_id).first() if tenant_id else None
    default_tax_rate = Decimal(str(t_setting.tax_rate)) if t_setting and getattr(t_setting, "tax_rate", None) is not None else Decimal("18.00")

    line_items_data = []
    staff_sales_map = {}
    bill_sno = 1
    total_cash = Decimal("0.00")
    total_paytm = Decimal("0.00")
    total_card = Decimal("0.00")
    total_amt = Decimal("0.00")
    total_gst = Decimal("0.00")
    grand_total = Decimal("0.00")

    for inv in invoices:
        pm_list = InvoicePayment.query.filter_by(invoice_id=inv.id).all()
        
        def _categorize_pm(p):
            m = str(getattr(p, "payment_method", getattr(p, "method", "")) or "").strip().lower()
            if "cash" in m:
                return "cash"
            elif "card" in m:
                return "card"
            return "paytm"  # UPI, Paytm, Google Pay, PhonePe, Net Banking, etc.

        if pm_list:
            cash_paid = sum(Decimal(str(p.amount or 0)) for p in pm_list if _categorize_pm(p) == "cash")
            paytm_paid = sum(Decimal(str(p.amount or 0)) for p in pm_list if _categorize_pm(p) == "paytm")
            card_paid = sum(Decimal(str(p.amount or 0)) for p in pm_list if _categorize_pm(p) == "card")
        else:
            cash_paid = Decimal(str(inv.total or 0))
            paytm_paid = Decimal("0.00")
            card_paid = Decimal("0.00")

        inv_subtotal = Decimal(str(getattr(inv, "subtotal", 0) or 0))
        inv_discount = Decimal(str(getattr(inv, "discount", 0) or 0))
        if inv_discount == Decimal("0.00") and getattr(inv, "membership_discount", None):
            inv_discount = Decimal(str(inv.membership_discount or 0))
        inv_tax = Decimal(str(getattr(inv, "tax", 0) or 0))
        inv_total = Decimal(str(getattr(inv, "total", 0) or 0))
        if inv_total == Decimal("0.00"):
            inv_total = max(Decimal("0.00"), inv_subtotal - inv_discount + inv_tax)

        client_name = "Walk-in"
        if getattr(inv, "customer", None):
            c_first = getattr(inv.customer, "first_name", "") or ""
            c_last = getattr(inv.customer, "last_name", "") or ""
            full_c = f"{c_first} {c_last}".strip()
            if full_c:
                client_name = full_c
            elif getattr(inv.customer, "name", None):
                client_name = inv.customer.name

        items = getattr(inv, "items", []) or []
        num_items = len(items)

        if num_items == 0:
            # Fallback if an invoice has no items recorded
            r_tot = int(inv_total.quantize(Decimal("1"), rounding=ROUND_HALF_UP))
            r_gst = int(inv_tax.quantize(Decimal("1"), rounding=ROUND_HALF_UP))
            r_amt = r_tot - r_gst
            r_cash = int(Decimal(str(cash_paid)).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
            r_paytm = int(Decimal(str(paytm_paid)).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
            r_card = int(Decimal(str(card_paid)).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
            if (cash_paid + paytm_paid + card_paid) >= inv_total and (r_cash + r_paytm + r_card) != r_tot:
                r_cash = r_tot - (r_paytm + r_card)
            line_items_data.append({
                "sno": bill_sno,
                "invoice_id": inv.id,
                "client_name": client_name,
                "bill_total": r_tot,
                "is_first_staff": True,
                "staff_count": 1,
                "service": "General Sale",
                "staff": "Staff",
                "amt": r_amt,
                "gst": r_gst,
                "cash": r_cash,
                "paytm": r_paytm,
                "card": r_card,
                "mc": 0,
                "total": r_tot
            })
            total_amt += Decimal(str(r_amt))
            total_gst += Decimal(str(r_gst))
            grand_total += Decimal(str(r_tot))
            total_cash += Decimal(str(r_cash))
            total_paytm += Decimal(str(r_paytm))
            total_card += Decimal(str(r_card))
            bill_sno += 1
            continue

        # Group items by staff within this invoice
        # Ensures all services done by the same staff in this bill are combined into 1 clean row
        from collections import OrderedDict, Counter
        staff_groups = OrderedDict()
        for item in items:
            is_membership = (not getattr(item, "service_id", None)) and (not getattr(item, "product_id", None))
            if is_membership:
                mem_title = inv.membership_name
                if not mem_title and getattr(inv, "customer_id", None):
                    try:
                        from app.models.membership import CustomerMembership
                        cm = CustomerMembership.query.filter_by(tenant_id=inv.tenant_id, customer_id=inv.customer_id).order_by(CustomerMembership.id.desc()).first()
                        if cm and getattr(cm, "plan", None):
                            mem_title = cm.plan.name
                    except Exception:
                        pass
                if mem_title:
                    serv_name = mem_title if mem_title.lower().startswith("membership") else f"Membership ({mem_title})"
                else:
                    serv_name = "Membership Plan"
                emp_name = "Membership"
            elif getattr(item, "service", None):
                serv_name = item.service.name
                emp_name = f"{item.employee.first_name} {item.employee.last_name or ''}".strip() if getattr(item, "employee", None) else "Staff"
            elif getattr(item, "product", None):
                serv_name = f"{item.product.name} (Product)"
                emp_name = f"{item.employee.first_name} {item.employee.last_name or ''}".strip() if getattr(item, "employee", None) else "Front Desk"
            else:
                serv_name = "Service Item"
                emp_name = f"{item.employee.first_name} {item.employee.last_name or ''}".strip() if getattr(item, "employee", None) else "Staff"
            unit_price = Decimal(str(getattr(item, "unit_price", 0) or 0))
            quantity = Decimal(str(getattr(item, "quantity", 1) or 1))
            gross_amt = unit_price * quantity
            item_disc = Decimal(str(getattr(item, "discount_amount", 0) or 0))
            net_amt = max(Decimal("0.00"), gross_amt - item_disc)

            if emp_name not in staff_groups:
                staff_groups[emp_name] = {
                    "services": [],
                    "net_sum": Decimal("0.00")
                }
            staff_groups[emp_name]["services"].append(serv_name)
            staff_groups[emp_name]["net_sum"] += net_amt

        num_groups = len(staff_groups)
        tot_bill_amt = int(max(Decimal("0.00"), inv_subtotal - inv_discount).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
        tot_bill_gst = int(inv_tax.quantize(Decimal("1"), rounding=ROUND_HALF_UP))
        tot_bill_total = int(inv_total.quantize(Decimal("1"), rounding=ROUND_HALF_UP))
        # Ensure tot_bill_amt + tot_bill_gst == tot_bill_total
        if tot_bill_amt + tot_bill_gst != tot_bill_total:
            tot_bill_amt = tot_bill_total - tot_bill_gst

        tot_cash_int = int(Decimal(str(cash_paid)).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
        tot_paytm_int = int(Decimal(str(paytm_paid)).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
        tot_card_int = int(Decimal(str(card_paid)).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
        if (cash_paid + paytm_paid + card_paid) >= inv_total and (tot_cash_int + tot_paytm_int + tot_card_int) != tot_bill_total:
            diff = tot_bill_total - (tot_cash_int + tot_paytm_int + tot_card_int)
            if tot_cash_int >= max(tot_paytm_int, tot_card_int):
                tot_cash_int += diff
            elif tot_paytm_int >= tot_card_int:
                tot_paytm_int += diff
            else:
                tot_card_int += diff

        total_group_net = sum(grp["net_sum"] for grp in staff_groups.values())

        sum_prev_amt = 0
        sum_prev_gst = 0
        sum_prev_tot = 0
        sum_prev_cash = 0
        sum_prev_paytm = 0
        sum_prev_card = 0

        grp_list = list(staff_groups.items())
        for g_idx, (emp_name, grp) in enumerate(grp_list):
            is_last = (g_idx == num_groups - 1)

            cnt = Counter(grp["services"])
            combined_services = ", ".join(f"{s} (x{c})" if c > 1 else s for s, c in cnt.items())

            if is_last:
                r_line_amt = tot_bill_amt - sum_prev_amt
                r_line_gst = tot_bill_gst - sum_prev_gst
                r_line_total = tot_bill_total - sum_prev_tot
                r_item_cash = tot_cash_int - sum_prev_cash
                r_item_paytm = tot_paytm_int - sum_prev_paytm
                r_item_card = tot_card_int - sum_prev_card
            else:
                ratio = (grp["net_sum"] / total_group_net) if total_group_net > Decimal("0.00") else (Decimal("1.00") / Decimal(str(num_groups)))
                r_line_amt = int((Decimal(str(tot_bill_amt)) * ratio).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
                r_line_gst = int((Decimal(str(tot_bill_gst)) * ratio).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
                r_line_total = r_line_amt + r_line_gst
                r_item_cash = int((Decimal(str(tot_cash_int)) * ratio).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
                r_item_paytm = int((Decimal(str(tot_paytm_int)) * ratio).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
                r_item_card = int((Decimal(str(tot_card_int)) * ratio).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
                if (r_item_cash + r_item_paytm + r_item_card) != r_line_total:
                    diff = r_line_total - (r_item_cash + r_item_paytm + r_item_card)
                    if r_item_cash >= max(r_item_paytm, r_item_card):
                        r_item_cash += diff
                    elif r_item_paytm >= r_item_card:
                        r_item_paytm += diff
                    else:
                        r_item_card += diff

                sum_prev_amt += r_line_amt
                sum_prev_gst += r_line_gst
                sum_prev_tot += r_line_total
                sum_prev_cash += r_item_cash
                sum_prev_paytm += r_item_paytm
                sum_prev_card += r_item_card

            total_amt += Decimal(str(r_line_amt))
            total_gst += Decimal(str(r_line_gst))
            grand_total += Decimal(str(r_line_total))
            total_cash += Decimal(str(r_item_cash))
            total_paytm += Decimal(str(r_item_paytm))
            total_card += Decimal(str(r_item_card))

            if emp_name not in staff_sales_map:
                staff_sales_map[emp_name] = Decimal("0.00")
            staff_sales_map[emp_name] += Decimal(str(r_line_amt))

            line_items_data.append({
                "sno": bill_sno,
                "invoice_id": inv.id,
                "client_name": client_name,
                "bill_total": tot_bill_total,
                "is_first_staff": (g_idx == 0),
                "staff_count": num_groups,
                "service": combined_services,
                "staff": emp_name,
                "amt": r_line_amt,
                "gst": r_line_gst,
                "cash": r_item_cash,
                "paytm": r_item_paytm,
                "card": r_item_card,
                "mc": 0,
                "total": r_line_total
            })

        bill_sno += 1

    # Expenses for date
    expenses = []
    if tenant_id and branch_id:
        expenses = Expense.query.filter_by(tenant_id=tenant_id, branch_id=branch_id, is_deleted=False).filter(Expense.date == target_date).all()
    expense_list = [{"note": exp.note or "Expense", "amount": float(exp.amount or 0)} for exp in expenses]
    total_expenses = float(sum(exp["amount"] for exp in expense_list))

    # Cash Denominations
    cd_rec = CashDenomination.query.filter_by(tenant_id=tenant_id, branch_id=branch_id, date=target_date).first() if tenant_id and branch_id else None
    cd_data = {
        "500": getattr(cd_rec, "count_500", 0) if cd_rec else 0,
        "200": getattr(cd_rec, "count_200", 0) if cd_rec else 0,
        "100": getattr(cd_rec, "count_100", 0) if cd_rec else 0,
        "50": getattr(cd_rec, "count_50", 0) if cd_rec else 0,
        "20": getattr(cd_rec, "count_20", 0) if cd_rec else 0,
        "10": getattr(cd_rec, "count_10", 0) if cd_rec else 0,
        "5": getattr(cd_rec, "count_5", 0) if cd_rec else 0,
        "2": getattr(cd_rec, "count_2", 0) if cd_rec else 0,
        "1": getattr(cd_rec, "count_1", 0) if cd_rec else 0,
        "total": float(getattr(cd_rec, "total", 0) or 0) if cd_rec else 0.0
    }

    # Opening Cash Balance is strictly yesterday's closing cash balance
    prev_invoices = get_branch_query(Invoice).filter(
        Invoice.created_at < start_dt,
        Invoice.status != "Voided"
    ).all()

    prev_cash_sum = Decimal("0.00")
    for inv in prev_invoices:
        pm_list = InvoicePayment.query.filter_by(invoice_id=inv.id).all()
        if pm_list:
            prev_cash_sum += sum(Decimal(str(p.amount or 0)) for p in pm_list if str(getattr(p, "payment_method", getattr(p, "method", ""))).lower() == "cash")
        else:
            prev_cash_sum += Decimal(str(inv.total or 0))

    prev_expenses_q = Expense.query.filter_by(tenant_id=tenant_id, is_deleted=False).filter(Expense.date < target_date) if tenant_id else None
    if prev_expenses_q and branch_id:
        prev_expenses_q = prev_expenses_q.filter_by(branch_id=branch_id)
    prev_exp_sum = sum(Decimal(str(exp.amount or 0)) for exp in (prev_expenses_q.all() if prev_expenses_q else []))

    init_bal = Decimal(str(getattr(branch, "initial_opening_balance", 0) or 0)) if branch else Decimal("0.00")
    opening_bal = float(init_bal + prev_cash_sum - prev_exp_sum)
    if opening_bal < 0:
        opening_bal = 0.0

    closing_bal = opening_bal + float(total_cash) - total_expenses

    staff_achieved_list = [
        {"sno": idx + 1, "staff_name": k, "achieved": float(v)}
        for idx, (k, v) in enumerate([(k, v) for k, v in staff_sales_map.items() if k != "Membership"])
    ]

    # Month till date stats
    first_of_month = target_date.replace(day=1)
    month_invoices = get_branch_query(Invoice).filter(
        Invoice.created_at >= datetime.combine(first_of_month, datetime.min.time()),
        Invoice.created_at <= end_dt,
        Invoice.status != "Voided"
    ).all()

    till_date_sales = sum(float((getattr(inv, "subtotal", 0) or 0) - (getattr(inv, "discount", 0) or 0)) for inv in month_invoices)
    till_date_gst = sum(float(getattr(inv, "tax", 0) or 0) for inv in month_invoices)
    till_date_walkin = len(set(inv.customer_id for inv in month_invoices if getattr(inv, "customer_id", None)))
    till_date_abv = (till_date_sales / till_date_walkin) if till_date_walkin > 0 else 0.0

    return success_response({
        "parlour_name": parlour_name,
        "branch_name": branch_name,
        "date_str": target_date.strftime("%d/%m/%Y"),
        "day_name": target_date.strftime("%A").upper(),
        "line_items": line_items_data,
        "totals": {
            "amt": int(Decimal(str(total_amt)).quantize(Decimal("1"), rounding=ROUND_HALF_UP)),
            "gst": int(Decimal(str(total_gst)).quantize(Decimal("1"), rounding=ROUND_HALF_UP)),
            "cash": int(Decimal(str(total_cash)).quantize(Decimal("1"), rounding=ROUND_HALF_UP)),
            "paytm": int(Decimal(str(total_paytm)).quantize(Decimal("1"), rounding=ROUND_HALF_UP)),
            "card": int(Decimal(str(total_card)).quantize(Decimal("1"), rounding=ROUND_HALF_UP)),
            "total": int(Decimal(str(grand_total)).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
        },
        "expenses": expense_list,
        "total_expenses": int(round(total_expenses)),
        "balance": {
            "opening_bal": int(round(opening_bal)),
            "is_manual_opening": False,
            "total_sale": int(Decimal(str(grand_total)).quantize(Decimal("1"), rounding=ROUND_HALF_UP)),
            "cash_pay": int(Decimal(str(total_cash)).quantize(Decimal("1"), rounding=ROUND_HALF_UP)),
            "phone_pay": int(Decimal(str(total_paytm)).quantize(Decimal("1"), rounding=ROUND_HALF_UP)),
            "card": int(Decimal(str(total_card)).quantize(Decimal("1"), rounding=ROUND_HALF_UP)),
            "expense": int(round(total_expenses)),
            "closing_bal": int(round(closing_bal))
        },
        "cash_denomination": cd_data,
        "staff_achieved": staff_achieved_list,
        "till_date": {
            "sales": round(till_date_sales, 2),
            "with_gst": round(till_date_sales + till_date_gst, 2),
            "walkin": till_date_walkin,
            "abv": round(till_date_abv, 4)
        }
    })


@reports_bp.route("/reports/daily-sales-statement/opening-balance", methods=["POST"])
@reports_bp.route("/daily-sales-statement/opening-balance", methods=["POST"])
@require_role(["ParlourAdmin", "BranchAdmin", "Receptionist"])
def update_daily_opening_balance():
    data = request.get_json() or {}
    date_str = data.get("date")
    opening_bal_val = data.get("opening_balance")
    branch_id = data.get("branch_id") or getattr(g, "branch_id", None) or 1
    tenant_id = getattr(g, "parlour_id", None) or getattr(g, "tenant_id", 1)

    if not date_str:
        return error_response("MISSING_DATE", "Date is required.", 400)
    try:
        target_date = datetime.strptime(date_str, "%Y-%m-%d").date()
    except ValueError:
        return error_response("INVALID_DATE", "Date must be YYYY-MM-DD.", 400)

    from app.models.cash_denomination import CashDenomination
    cd_rec = CashDenomination.query.filter_by(
        tenant_id=tenant_id,
        branch_id=branch_id,
        date=target_date
    ).first()

    val_dec = Decimal(str(opening_bal_val)) if opening_bal_val is not None else Decimal("0.00")

    if cd_rec:
        cd_rec.opening_balance = val_dec
    else:
        cd_rec = CashDenomination(
            tenant_id=tenant_id,
            branch_id=branch_id,
            date=target_date,
            opening_balance=val_dec,
            total=0.0
        )
        db.session.add(cd_rec)
    db.session.commit()

    return success_response({
        "message": "Opening balance updated successfully.",
        "date": target_date.isoformat(),
        "opening_balance": float(val_dec)
    })


@reports_bp.route("/reports/monthly-performance-staff", methods=["GET"])
@require_role(["ParlourAdmin", "BranchAdmin", "Receptionist"])
def get_monthly_performance_staff():
    month = request.args.get("month", type=int) or date.today().month
    year = request.args.get("year", type=int) or date.today().year
    branch_id = getattr(g, "branch_id", None) or request.args.get("branch_id", type=int) or 1

    from app.models.branch import Branch
    all_branches = {b.id: b.name for b in Branch.query.all()}

    _, last_day = calendar.monthrange(year, month)
    start_dt = datetime(year, month, 1, 0, 0, 0)
    end_dt = datetime(year, month, last_day, 23, 59, 59)

    employees = get_branch_query(Employee).filter_by(status="active").all()
    invoices = get_tenant_query(Invoice).filter(
        Invoice.created_at >= start_dt,
        Invoice.created_at <= end_dt,
        Invoice.status != "Voided"
    ).all()

    if branch_id:
        invoices_filtered = [inv for inv in invoices if inv.branch_id == branch_id]
    else:
        invoices_filtered = invoices

    staff_records = []
    tot_achieved = 0.0
    tot_with_gst = 0.0
    tot_walkin = 0

    salon_male_sales = 0.0
    salon_male_walkin = set()
    salon_female_sales = 0.0
    salon_female_walkin = set()

    for idx, emp in enumerate(employees):
        emp_cust_set = set()
        emp_achieved = 0.0
        emp_branch_map = {}

        for inv in invoices:
            for item in inv.items:
                # Target achieved is strictly calculated ONLY from Services (service_id is present)
                if item.employee_id == emp.id and item.service_id is not None:
                    line_tot = float(item.line_total)
                    if not branch_id or inv.branch_id == branch_id:
                        emp_achieved += line_tot
                        if inv.customer_id:
                            emp_cust_set.add(inv.customer_id)
                            cust = inv.customer
                            if cust and getattr(cust, "gender", "").lower() == "male":
                                salon_male_sales += line_tot
                                salon_male_walkin.add(inv.customer_id)
                            else:
                                salon_female_sales += line_tot
                                salon_female_walkin.add(inv.customer_id)

                    # Track sales per branch for multi-branch staff breakdown
                    b_id = inv.branch_id
                    if b_id:
                        if b_id not in emp_branch_map:
                            emp_branch_map[b_id] = {
                                "branch_id": b_id,
                                "branch_name": all_branches.get(b_id, f"Branch {b_id}"),
                                "achieved": 0.0
                            }
                        emp_branch_map[b_id]["achieved"] += line_tot

        walkin_cnt = len(emp_cust_set)
        salary_val = float(emp.salary or 0.0)
        target_val = float(emp.target or 0.0)
        abv_val = (emp_achieved / walkin_cnt) if walkin_cnt > 0 else 0.0
        pct_val = ((emp_achieved / target_val) * 100.0) if target_val > 0 else 0.0

        tot_achieved += emp_achieved
        tot_with_gst += emp_achieved
        tot_walkin += walkin_cnt

        branch_breakdown = list(emp_branch_map.values())

        staff_records.append({
            "sno": idx + 1,
            "id": emp.id,
            "name": f"{emp.first_name} {emp.last_name or ''}".strip(),
            "level": emp.level or "L1",
            "salary": salary_val,
            "target": target_val,
            "achieved": round(emp_achieved, 2),
            "with_gst": round(emp_achieved, 2),
            "walkin": walkin_cnt,
            "abv": round(abv_val, 4),
            "percentage": round(pct_val, 1),
            "review": 0,
            "mc": "",
            "branch_breakdown": branch_breakdown if g.role == "ParlourAdmin" else []
        })

    all_walkin_cnt = len(set(inv.customer_id for inv in invoices_filtered if inv.customer_id))
    all_abv = (tot_achieved / all_walkin_cnt) if all_walkin_cnt > 0 else 0.0
    male_abv = (salon_male_sales / len(salon_male_walkin)) if len(salon_male_walkin) > 0 else 0.0
    female_abv = (salon_female_sales / len(salon_female_walkin)) if len(salon_female_walkin) > 0 else 0.0

    return success_response({
        "month_year": f"{calendar.month_name[month].upper()}-{year}",
        "staff_performance": staff_records,
        "totals": {
            "achieved": round(tot_achieved, 2),
            "with_gst": round(tot_with_gst, 2),
            "walkin": tot_walkin
        },
        "summary": {
            "salon_sales": {
                "sales": round(tot_achieved, 2),
                "walkin": all_walkin_cnt,
                "abv": round(all_abv, 4),
                "with_gst": round(tot_with_gst, 2)
            },
            "male_sales": {
                "sales": round(salon_male_sales, 2),
                "walkin": len(salon_male_walkin),
                "abv": round(male_abv, 4)
            },
            "female_sales": {
                "sales": round(salon_female_sales, 2),
                "walkin": len(salon_female_walkin),
                "abv": round(female_abv, 4)
            }
        }
    })


@reports_bp.route("/reports/attendance-salary-report", methods=["GET"])
@require_role(["ParlourAdmin", "BranchAdmin", "Receptionist"])
def get_attendance_salary_report():
    month = request.args.get("month", type=int) or date.today().month
    year = request.args.get("year", type=int) or date.today().year
    branch_id = getattr(g, "branch_id", None) or request.args.get("branch_id", type=int) or 1

    from app.models.attendance import Attendance
    from app.models.payroll_adjustment import PayrollAdjustment

    _, total_days = calendar.monthrange(year, month)
    start_dt = datetime(year, month, 1, 0, 0, 0)
    end_dt = datetime(year, month, total_days, 23, 59, 59)
    today_curr = date.today()

    days_list = []
    for d in range(1, total_days + 1):
        dt_val = date(year, month, d)
        days_list.append({
            "day": d,
            "day_name": dt_val.strftime("%A"),
            "full_date_label": dt_val.strftime("%A, %B %d, %Y")
        })

    employees = get_branch_query(Employee).filter_by(status="active").all()
    att_q = Attendance.query.filter(
        Attendance.timestamp >= start_dt,
        Attendance.timestamp <= end_dt
    )
    if branch_id:
        att_q = att_q.filter(Attendance.branch_id == branch_id)
    attendances = att_q.all()

    invoices = get_tenant_query(Invoice).filter(
        Invoice.created_at >= start_dt,
        Invoice.created_at <= end_dt,
        Invoice.status != "Voided"
    ).all()
    if branch_id:
        invoices = [inv for inv in invoices if inv.branch_id == branch_id]

    try:
        payroll_adjs = get_branch_query(PayrollAdjustment).filter(
            PayrollAdjustment.date >= start_dt.date(),
            PayrollAdjustment.date <= end_dt.date()
        ).all()
    except Exception:
        db.session.rollback()
        payroll_adjs = []

    att_matrix = []
    salary_rows = []

    tot_salary = 0.0
    tot_per_day = 0.0
    tot_target = 0.0
    tot_achieved = 0.0
    tot_net = 0.0
    tot_advance = 0.0
    tot_less = 0.0
    tot_payable = 0.0

    for idx, emp in enumerate(employees):
        emp_att_map = {}

        # Default unlogged past dates and future dates to blank ""
        for d in range(1, total_days + 1):
            dt_val = date(year, month, d)
            if dt_val > today_curr:
                emp_att_map[str(d)] = ""  # Future date -> Blank
            else:
                emp_att_map[str(d)] = ""  # Past date unlogged -> Blank

        emp_atts = [att for att in attendances if att.employee_id == emp.id]
        off_count = 0
        leave_count = 0
        double_leave_count = 0
        total_worked_days = 0.0

        for att in emp_atts:
            day_num = att.timestamp.day
            dt_val = att.timestamp.date()
            if dt_val > today_curr:
                continue
            st = getattr(att, "status", "P") or "P"
            if st in ["P", "Present"]:
                emp_att_map[str(day_num)] = "1"
            elif st in ["HP", "HalfDay", "Half-Day"]:
                emp_att_map[str(day_num)] = "0.5"
            elif st in ["OFF", "F", "DayOff"]:
                emp_att_map[str(day_num)] = "F"
            elif st in ["2L", "L_DOUBLE", "2"]:
                emp_att_map[str(day_num)] = "2L"
            elif st in ["L", "Leave"]:
                emp_att_map[str(day_num)] = "L"

        for d in range(1, total_days + 1):
            val = emp_att_map[str(d)]
            dt_val = date(year, month, d)
            is_weekend = dt_val.weekday() in [5, 6]  # 5 is Saturday, 6 is Sunday

            if val == "1":
                total_worked_days += 1.0
            elif val == "0.5":
                if is_weekend:
                    # Half day on Saturday or Sunday: deducts 1 full day of salary instead of 0.5 day
                    # Full day is 1.0; deducting 1.0 gives 0.0 credit for this day.
                    total_worked_days += 0.0
                else:
                    total_worked_days += 0.5
            elif val in ["OFF", "F"]:
                off_count += 1
            elif val == "L":
                leave_count += 1
            elif val == "2L":
                double_leave_count += 1

        allowed_offs = getattr(emp, "monthly_offs", 4) or 4
        # 4 offs are paid offs (no deduction). Any extra offs beyond 4 are unpaid.
        paid_offs = min(off_count, allowed_offs)

        att_matrix.append({
            "sno": idx + 1,
            "id": emp.id,
            "name": f"{emp.first_name} {emp.last_name or ''}".strip(),
            "days": emp_att_map,
            "total_days": round(total_worked_days + paid_offs, 1),
            "leaves_taken": off_count + leave_count + double_leave_count,
            "allowed_offs": allowed_offs,
            "leaves_summary": f"{off_count + leave_count + double_leave_count}/{allowed_offs}"
        })

        # Achieved revenue this month (strictly calculated ONLY from Services)
        emp_achieved = 0.0
        for inv in invoices:
            for item in inv.items:
                if item.employee_id == emp.id and item.service_id is not None:
                    emp_achieved += float(item.line_total)

        # Advances & Deductions from PayrollAdjustment
        emp_adjs = [pa for pa in payroll_adjs if pa.employee_id == emp.id]
        emp_advances = sum(float(pa.amount) for pa in emp_adjs if pa.type == "Advance")
        emp_deductions = sum(float(pa.amount) for pa in emp_adjs if pa.type in ["Deduction", "Less"])

        salary_val = float(emp.salary or 0.0)
        target_val = float(emp.target or 0.0)
        per_day_salary = round(salary_val / total_days, 2) if total_days > 0 and salary_val > 0 else 0.0

        # Effective paid days: worked days + paid offs (4 allowed offs won't deduct salary)
        effective_paid_days = total_worked_days + paid_offs

        # 2L leaves deduct double amount (1 day already uncredited from work + 1 extra day penalty)
        double_leave_penalty = double_leave_count * per_day_salary

        net_salary = round(max((per_day_salary * effective_paid_days) - double_leave_penalty, 0.0), 2) if salary_val > 0 else 0.0
        
        # FINAL PAYABLE = NET - ADVANCE - DEDUCTIONS
        final_payable = round(max(net_salary - emp_advances - emp_deductions, 0.0), 2)

        tot_salary += salary_val
        tot_per_day += per_day_salary
        tot_target += target_val
        tot_achieved += emp_achieved
        tot_net += net_salary
        tot_advance += emp_advances
        tot_less += emp_deductions
        tot_payable += final_payable

        salary_rows.append({
            "sno": idx + 1,
            "id": emp.id,
            "name": f"{emp.first_name} {emp.last_name or ''}".strip(),
            "salary": salary_val,
            "per_day": per_day_salary,
            "target": target_val,
            "achieved": round(emp_achieved, 2),
            "off": off_count,
            "leave": leave_count + double_leave_count,
            "allowed_offs": allowed_offs,
            "leaves_summary": f"{off_count + leave_count + double_leave_count}/{allowed_offs}",
            "total_days": round(effective_paid_days, 1),
            "net": net_salary,
            "advance": emp_advances,
            "less_amount": emp_deductions,
            "amount": final_payable
        })

    return success_response({
        "month_year": f"{calendar.month_name[month].upper()}-{str(year)[-2:]}",
        "days_in_month": days_list,
        "attendance_matrix": att_matrix,
        "salary_report": salary_rows,
        "totals": {
            "salary": round(tot_salary, 2),
            "per_day": round(tot_per_day, 2),
            "target": round(tot_target, 2),
            "achieved": round(tot_achieved, 2),
            "net": round(tot_net, 2),
            "advance": round(tot_advance, 2),
            "less_amount": round(tot_less, 2),
            "amount": round(tot_payable, 2)
        }
    })
