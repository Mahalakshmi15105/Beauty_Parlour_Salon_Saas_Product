from flask import Blueprint, request, g
from app.database import db
from app.models.customer import Customer
from app.models.billing import Invoice
from app.models.user import TenantSetting
from app.utils.responses import success_response, error_response
from app.utils.auth import require_role, get_tenant_query, get_branch_query
from app.utils.query import paginate_query
from datetime import datetime, timedelta, timezone
from sqlalchemy import func, or_, and_
import logging

logger = logging.getLogger(__name__)
customers_bp = Blueprint("customers", __name__)

from app.services.cache import cache

@customers_bp.route("/customers", methods=["GET"])
@require_role(["ParlourAdmin", "BranchAdmin"])
def get_customers():
    # Parse query parameters
    q = request.args.get("q", "").strip()
    gender = request.args.get("gender", "").strip()
    limit = request.args.get("limit", 20)
    cursor = request.args.get("cursor")
    sort = request.args.get("sort", "-created_at")
    is_all = request.args.get("all", "").strip().lower() in ["true", "1", "yes"]

    # 0. Check Redis cache first
    b_param = request.headers.get("X-Branch-Id") or request.args.get("branch_id")
    b_key = b_param or g.branch_id or "all"
    cache_key = f"customers:{g.parlour_id}:{b_key}:{q}:{gender}:{limit}:{cursor}:{sort}:{is_all}"
    try:
        cached_data = cache.get(cache_key)
        if cached_data is not None:
            return success_response(cached_data)
    except Exception as c_err:
        logger.debug(f"Cache get error: {c_err}")

    try:
        # Start query: if searching by keyword/phone or branch_id='all', search tenant-wide
        if q or b_param == "all":
            query = get_tenant_query(Customer)
        else:
            query = get_branch_query(Customer)

        # Search filter
        if q:
            clean_digits = "".join(filter(str.isdigit, q))
            search_conds = [
                Customer.first_name.ilike(f"%{q}%"),
                Customer.last_name.ilike(f"%{q}%"),
                Customer.phone.ilike(f"%{q}%"),
                Customer.email.ilike(f"%{q}%")
            ]
            if clean_digits and len(clean_digits) >= 4:
                search_conds.append(Customer.phone.ilike(f"%{clean_digits}%"))
            query = query.filter(or_(*search_conds))

        # Gender filter
        if gender:
            query = query.filter(Customer.gender == gender)

        # Total counts
        total_count = query.count()
        total_all = get_tenant_query(Customer).count()

        if is_all:
            # Full export without pagination
            all_customers = query.order_by(Customer.first_name.asc(), Customer.id.asc()).all()
            data = [
                {
                    "id": c.id,
                    "first_name": c.first_name or "",
                    "last_name": c.last_name or "",
                    "phone": c.phone or "",
                    "email": c.email or "",
                    "gender": c.gender or "Other",
                    "date_of_birth": c.date_of_birth.isoformat() if c.date_of_birth else None,
                    "address": c.address or "",
                    "notes": c.notes or "",
                    "spot": c.spot or "",
                    "branch_id": c.branch_id,
                    "created_at": c.created_at.isoformat() if c.created_at else ""
                } for c in all_customers
            ]
            result_payload = {
                "items": data,
                "next_cursor": None,
                "total_count": total_count,
                "total_customers": total_all
            }
        else:
            # Keyset pagination for fast UI scrolling
            sort_field = "id"
            sort_desc = False
            if sort.startswith("-"):
                sort_field = sort[1:]
                sort_desc = True
            else:
                sort_field = sort

            customers, next_cursor = paginate_query(
                query=query,
                model=Customer,
                limit_val=limit,
                cursor=cursor,
                sort_field=sort_field,
                sort_desc=sort_desc
            )

            data = [
                {
                    "id": c.id,
                    "first_name": c.first_name or "",
                    "last_name": c.last_name or "",
                    "phone": c.phone or "",
                    "email": c.email or "",
                    "gender": c.gender or "Other",
                    "date_of_birth": c.date_of_birth.isoformat() if c.date_of_birth else None,
                    "address": c.address or "",
                    "notes": c.notes or "",
                    "spot": c.spot or "",
                    "branch_id": c.branch_id,
                    "created_at": c.created_at.isoformat() if c.created_at else ""
                } for c in (customers or [])
            ]

            result_payload = {
                "items": data,
                "next_cursor": next_cursor,
                "total_count": total_count,
                "total_customers": total_all
            }

        try:
            cache.set(cache_key, result_payload, timeout=300)
        except Exception:
            pass

        return success_response(result_payload)
    except Exception as cust_err:
        logger.warning(f"Customers query fallback: {cust_err}")
        return success_response({
            "items": [],
            "next_cursor": None,
            "total_count": 0,
            "total_customers": 0
        })


@customers_bp.route("/customers/<int:customer_id>", methods=["GET"])
@require_role(["ParlourAdmin", "BranchAdmin"])
def get_customer(customer_id):
    customer = get_branch_query(Customer).filter_by(id=customer_id).first()
    if not customer:
        return error_response(
            error_code="CUSTOMER_NOT_FOUND",
            message="Customer not found or access denied.",
            status_code=404
        )
    return success_response({
        "id": customer.id,
        "first_name": customer.first_name,
        "last_name": customer.last_name,
        "phone": customer.phone,
        "email": customer.email,
        "gender": customer.gender,
        "date_of_birth": customer.date_of_birth.isoformat() if customer.date_of_birth else None,
        "address": customer.address,
        "notes": customer.notes,
        "spot": customer.spot,
        "branch_id": customer.branch_id,
        "created_at": customer.created_at.isoformat()
    })


@customers_bp.route("/customers", methods=["POST"])
@require_role(["ParlourAdmin", "BranchAdmin"])
def create_customer():
    data = request.get_json() or {}
    first_name = data.get("first_name", "").strip()
    phone = data.get("phone", "").strip()
    email = data.get("email", "").strip().lower() if data.get("email") else None
    
    # Validation
    if not first_name or not phone:
        return error_response(
            error_code="VALIDATION_FAILED",
            message="First name and phone number are required.",
            status_code=400
        )

    # Check duplicates in tenant context
    dup = get_tenant_query(Customer).filter_by(phone=phone).first()
    if dup:
        return error_response(
            error_code="DUPLICATE_RECORD",
            message=f"A customer with phone number {phone} already exists.",
            status_code=400,
            details={
                "existing_customer": {
                    "id": dup.id,
                    "first_name": dup.first_name,
                    "last_name": dup.last_name,
                    "phone": dup.phone
                }
            }
        )

    dob = None
    if data.get("date_of_birth"):
        from datetime import datetime
        try:
            dob = datetime.strptime(data["date_of_birth"], "%Y-%m-%d").date()
        except ValueError:
            return error_response(
                error_code="VALIDATION_FAILED",
                message="Date of birth must be in YYYY-MM-DD format.",
                status_code=400
            )

    # Determine branch_id automatically for BranchAdmin or validate for ParlourAdmin
    target_branch_id = None
    if g.role == "BranchAdmin":
        target_branch_id = g.branch_id
    elif data.get("branch_id"):
        try:
            bid = int(data["branch_id"])
            from app.models.branch import Branch
            b_exists = Branch.query.filter_by(id=bid, tenant_id=g.parlour_id, is_deleted=False).first()
            if not b_exists:
                return error_response(
                    error_code="INVALID_BRANCH",
                    message="The specified branch does not belong to your parlour.",
                    status_code=400
                )
            target_branch_id = bid
        except ValueError:
            pass
    elif getattr(g, "branch_id", None):
        target_branch_id = g.branch_id
    else:
        from app.models.branch import Branch
        main_b = Branch.query.filter_by(tenant_id=g.parlour_id, is_main_branch=True, is_deleted=False).first()
        if main_b:
            target_branch_id = main_b.id

    try:
        customer = Customer(
            tenant_id=g.parlour_id,
            branch_id=target_branch_id,
            first_name=first_name,
            last_name=data.get("last_name"),
            phone=phone,
            email=email,
            gender=data.get("gender"),
            date_of_birth=dob,
            address=data.get("address"),
            notes=data.get("notes"),
            spot=data.get("spot")
        )
        db.session.add(customer)
        db.session.commit()
        try:
            cache.delete_pattern(f"customers:{g.parlour_id}:*")
        except Exception:
            pass
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error creating customer: {str(e)}")
        return error_response(
            error_code="DATABASE_ERROR",
            message="Failed to create customer record.",
            status_code=500
        )

    return success_response({
        "id": customer.id,
        "first_name": customer.first_name,
        "last_name": customer.last_name,
        "phone": customer.phone,
        "email": customer.email,
        "gender": customer.gender,
        "date_of_birth": customer.date_of_birth.isoformat() if customer.date_of_birth else None,
        "address": customer.address,
        "notes": customer.notes,
        "spot": customer.spot,
        "branch_id": customer.branch_id,
        "created_at": customer.created_at.isoformat() if customer.created_at else None
    }, 201)


@customers_bp.route("/customers/<int:customer_id>", methods=["PUT"])
@require_role(["ParlourAdmin", "BranchAdmin"])
def update_customer(customer_id):
    customer = get_branch_query(Customer).filter_by(id=customer_id).first()
    if not customer:
        return error_response(
            error_code="CUSTOMER_NOT_FOUND",
            message="Customer not found or access denied.",
            status_code=404
        )

    data = request.get_json() or {}
    first_name = data.get("first_name", "").strip()
    phone = data.get("phone", "").strip()
    email = data.get("email", "").strip().lower() if data.get("email") else None

    if not first_name or not phone:
        return error_response(
            error_code="VALIDATION_FAILED",
            message="First name and phone number are required.",
            status_code=400
        )

    # Check duplicate phone for other records in tenant context
    dup = get_tenant_query(Customer).filter(Customer.phone == phone, Customer.id != customer_id).first()
    if dup:
        return error_response(
            error_code="DUPLICATE_RECORD",
            message=f"Another customer with phone number {phone} already exists.",
            status_code=400
        )

    dob = None
    if data.get("date_of_birth"):
        from datetime import datetime
        try:
            dob = datetime.strptime(data["date_of_birth"], "%Y-%m-%d").date()
        except ValueError:
            return error_response(
                error_code="VALIDATION_FAILED",
                message="Date of birth must be in YYYY-MM-DD format.",
                status_code=400
            )

    try:
        customer.first_name = first_name
        customer.last_name = data.get("last_name")
        customer.phone = phone
        customer.email = email
        customer.gender = data.get("gender")
        customer.date_of_birth = dob
        customer.address = data.get("address")
        customer.notes = data.get("notes")
        customer.spot = data.get("spot")
        if g.role == "ParlourAdmin" and data.get("branch_id") is not None:
            bid = data.get("branch_id")
            if bid is None:
                customer.branch_id = None
            else:
                try:
                    bid = int(bid)
                    from app.models.branch import Branch
                    b_exists = Branch.query.filter_by(id=bid, tenant_id=g.parlour_id, is_deleted=False).first()
                    if b_exists:
                        customer.branch_id = bid
                except ValueError:
                    pass
        db.session.commit()
        try:
            cache.delete_pattern(f"customers:{g.parlour_id}:*")
        except Exception:
            pass
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error updating customer: {str(e)}")
        return error_response(
            error_code="DATABASE_ERROR",
            message="Failed to update customer record.",
            status_code=500
        )

    return success_response({
        "id": customer.id,
        "first_name": customer.first_name,
        "last_name": customer.last_name,
        "phone": customer.phone,
        "email": customer.email,
        "gender": customer.gender,
        "date_of_birth": customer.date_of_birth.isoformat() if customer.date_of_birth else None,
        "address": customer.address,
        "notes": customer.notes,
        "spot": customer.spot,
        "created_at": customer.created_at.isoformat()
    })


@customers_bp.route("/customers/<int:customer_id>", methods=["DELETE"])
@require_role(["ParlourAdmin", "BranchAdmin"])
def delete_customer(customer_id):
    customer = get_branch_query(Customer).filter_by(id=customer_id).first()
    if not customer:
        return error_response(
            error_code="CUSTOMER_NOT_FOUND",
            message="Customer not found or access denied.",
            status_code=404
        )

    try:
        # 1. Clean up customer feedback, reminders, memberships
        from app.models.customer import CustomerFeedback, Reminder
        from app.models.membership import CustomerMembership, MembershipBenefit
        from app.models.appointment import Appointment, AppointmentItem
        from app.models.billing import Invoice

        try:
            CustomerFeedback.query.filter_by(customer_id=customer.id).delete()
        except Exception:
            pass

        try:
            Reminder.query.filter_by(customer_id=customer.id).delete()
        except Exception:
            pass

        try:
            memberships = CustomerMembership.query.filter_by(customer_id=customer.id).all()
            for m in memberships:
                MembershipBenefit.query.filter_by(customer_membership_id=m.id).delete()
                db.session.delete(m)
        except Exception:
            pass

        try:
            AppointmentItem.query.filter_by(customer_id=customer.id).update({"customer_id": None})
            Appointment.query.filter_by(customer_id=customer.id).update({"customer_id": None})
            Invoice.query.filter_by(customer_id=customer.id).update({"customer_id": None})
        except Exception:
            pass

        # 2. Permanently delete Customer record from tenant database
        db.session.delete(customer)
        db.session.commit()
        try:
            cache.delete_pattern(f"customers:{g.parlour_id}:*")
        except Exception:
            pass
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error permanently deleting customer: {str(e)}")
        return error_response(
            error_code="DATABASE_ERROR",
            message="Failed to delete customer record.",
            status_code=500
        )

    return success_response({"message": "Customer permanently deleted from database."})


@customers_bp.route("/customers/<int:customer_id>/memberships", methods=["GET"])
@require_role(["ParlourAdmin", "BranchAdmin"])
def get_customer_memberships(customer_id):
    from app.models.membership import CustomerMembership, MembershipBenefit
    
    # Verify customer exists in branch context
    customer = get_branch_query(Customer).filter_by(id=customer_id).first()
    if not customer:
        return error_response(
            error_code="CUSTOMER_NOT_FOUND",
            message="Customer not found.",
            status_code=404
        )

    # Fetch active memberships
    memberships = CustomerMembership.query.filter_by(
        customer_id=customer_id,
        tenant_id=g.parlour_id,
        status="active"
    ).all()

    data = []
    for m in memberships:
        benefits = []
        for b in m.benefits:
            benefits.append({
                "id": b.id,
                "service_id": b.service_id,
                "service_name": b.service.name if b.service else None,
                "total_quantity": b.total_quantity,
                "remaining_quantity": b.remaining_quantity
            })
        
        data.append({
            "id": m.id,
            "plan_name": m.plan.name if m.plan else "Default Membership",
            "expires_at": m.expires_at.isoformat(),
            "status": m.status,
            "benefits": benefits
        })

    return success_response(data)


@customers_bp.route("/customers/<int:customer_id>/history", methods=["GET"])
@require_role(["ParlourAdmin", "BranchAdmin"])
def get_customer_history(customer_id):
    from app.models.billing import Invoice, InvoiceLineItem, InvoicePayment
    from app.models.catalog import Service, Product
    from app.models.employee import Employee
    from app.models.membership import CustomerMembership, MembershipPlan, MembershipBenefit
    from collections import defaultdict
    from decimal import Decimal

    # 1. Verify customer exists in branch context
    customer = get_branch_query(Customer).filter_by(id=customer_id).first()
    if not customer:
        return error_response(
            error_code="CUSTOMER_NOT_FOUND",
            message="Customer not found or access denied.",
            status_code=404
        )

    # 2. Query customer's invoices (tenant + branch isolated)
    invoice_query = Invoice.query.filter_by(
        customer_id=customer_id,
        tenant_id=g.parlour_id
    )
    if g.role == "BranchAdmin" and g.branch_id:
        invoice_query = invoice_query.filter_by(branch_id=g.branch_id)
    invoices = invoice_query.order_by(Invoice.created_at.desc()).all()

    # 3. Query active/past memberships
    memberships = CustomerMembership.query.filter_by(
        customer_id=customer_id,
        tenant_id=g.parlour_id
    ).order_by(CustomerMembership.created_at.desc()).all()

    # Process Invoices & Line Items
    visit_history = []
    service_freq = defaultdict(lambda: {"count": 0, "last_date": None, "total_spent": Decimal("0.00")})
    product_freq = defaultdict(lambda: {"qty": 0, "last_date": None, "total_spent": Decimal("0.00")})
    stylist_freq = defaultdict(int)

    total_services_amount = Decimal("0.00")
    total_products_amount = Decimal("0.00")
    total_discounts_given = Decimal("0.00")
    total_tax_paid = Decimal("0.00")
    grand_total_spent = Decimal("0.00")

    timeline = []

    for inv in invoices:
        if inv.status and inv.status.lower() == "void":
            continue

        grand_total_spent += Decimal(str(inv.total or 0))
        total_discounts_given += Decimal(str(inv.discount or 0))
        total_tax_paid += Decimal(str(inv.tax or 0))

        inv_services = []
        inv_products = []
        inv_employees = set()

        line_items_data = []
        for line in inv.line_items:
            emp_name = "N/A"
            if line.employee_id:
                emp = db.session.get(Employee, line.employee_id)
                if emp:
                    emp_name = f"{emp.first_name} {emp.last_name or ''}".strip()
                    inv_employees.add(emp_name)
                    stylist_freq[emp_name] += 1

            if line.service_id:
                svc = db.session.get(Service, line.service_id)
                svc_name = svc.name if svc else "Service"
                inv_services.append(svc_name)
                service_freq[svc_name]["count"] += line.quantity
                service_freq[svc_name]["total_spent"] += Decimal(str(line.line_total or 0))
                if not service_freq[svc_name]["last_date"] or inv.created_at.isoformat() > service_freq[svc_name]["last_date"]:
                    service_freq[svc_name]["last_date"] = inv.created_at.strftime("%Y-%m-%d")
                total_services_amount += Decimal(str(line.line_total or 0))
                
                line_items_data.append({
                    "id": line.id,
                    "name": svc_name,
                    "type": "Service",
                    "quantity": line.quantity,
                    "unit_price": float(line.unit_price or 0),
                    "discount_amount": float(line.discount_amount or 0),
                    "line_total": float(line.line_total or 0),
                    "employee_name": emp_name
                })

            elif line.product_id:
                prod = db.session.get(Product, line.product_id)
                prod_name = prod.name if prod else "Product"
                inv_products.append(prod_name)
                product_freq[prod_name]["qty"] += line.quantity
                product_freq[prod_name]["total_spent"] += Decimal(str(line.line_total or 0))
                if not product_freq[prod_name]["last_date"] or inv.created_at.isoformat() > product_freq[prod_name]["last_date"]:
                    product_freq[prod_name]["last_date"] = inv.created_at.strftime("%Y-%m-%d")
                total_products_amount += Decimal(str(line.line_total or 0))

                line_items_data.append({
                    "id": line.id,
                    "name": prod_name,
                    "type": "Product",
                    "quantity": line.quantity,
                    "unit_price": float(line.unit_price or 0),
                    "discount_amount": float(line.discount_amount or 0),
                    "line_total": float(line.line_total or 0),
                    "employee_name": emp_name
                })

        payment_methods = [p.method for p in inv.payments] if inv.payments else ["Cash"]

        visit_row = {
            "id": inv.id,
            "invoice_number": inv.invoice_number,
            "created_at": inv.created_at.strftime("%Y-%m-%d %H:%M"),
            "date": inv.created_at.strftime("%d %b %Y"),
            "services": inv_services,
            "products": inv_products,
            "employees": list(inv_employees),
            "subtotal": float(inv.subtotal or 0),
            "discount": float(inv.discount or 0),
            "tax": float(inv.tax or 0),
            "total": float(inv.total or 0),
            "payment_methods": payment_methods,
            "status": inv.status,
            "line_items": line_items_data
        }
        visit_history.append(visit_row)

        items_desc = []
        if inv_services:
            items_desc.extend(inv_services)
        if inv_products:
            items_desc.extend([f"{p} (Product)" for p in inv_products])

        timeline.append({
            "date": inv.created_at.strftime("%d %b %Y"),
            "time": inv.created_at.strftime("%I:%M %p"),
            "type": "visit",
            "invoice_number": inv.invoice_number,
            "title": f"Salon Visit - {inv.invoice_number}",
            "items": items_desc,
            "amount": float(inv.total or 0)
        })

    purchased_services = [
        {
            "name": name,
            "times_taken": data["count"],
            "total_spent": float(data["total_spent"]),
            "last_taken_date": data["last_date"]
        } for name, data in service_freq.items()
    ]
    purchased_services.sort(key=lambda x: x["times_taken"], reverse=True)

    purchased_products = [
        {
            "name": name,
            "quantity_purchased": data["qty"],
            "total_spent": float(data["total_spent"]),
            "last_purchased_date": data["last_date"]
        } for name, data in product_freq.items()
    ]
    purchased_products.sort(key=lambda x: x["quantity_purchased"], reverse=True)

    memberships_data = []
    active_membership_name = None
    active_membership_status = "Inactive"

    import json
    for m in memberships:
        plan_name = m.plan.name if m.plan else "Membership Plan"
        if m.status == "active" and not active_membership_name:
            active_membership_name = plan_name
            active_membership_status = "Active"

        benefits = []
        for b in m.benefits:
            benefits.append({
                "service_name": b.service.name if b.service else "Service Perk",
                "total_quantity": b.total_quantity,
                "remaining_quantity": b.remaining_quantity
            })

        plan_services = []
        if m.plan and m.plan.eligible_services:
            for es in m.plan.eligible_services:
                plan_services.append({
                    "service_id": es.service_id,
                    "discount_percentage": float(es.discount_percentage or 0.0),
                    "discount_amount": float(es.discount_amount or 0.0)
                })

        memberships_data.append({
            "id": m.id,
            "membership_plan_id": m.membership_plan_id,
            "plan_id": m.membership_plan_id,
            "plan_name": plan_name,
            "start_date": m.created_at.strftime("%Y-%m-%d"),
            "expiry_date": m.expires_at.strftime("%Y-%m-%d") if m.expires_at else "N/A",
            "status": m.status,
            "service_discount_percentage": float(m.plan.service_discount_percentage) if m.plan else 0.0,
            "product_discount_percentage": float(m.plan.product_discount_percentage) if m.plan else 0.0,
            "day_restrictions": json.loads(m.plan.day_restrictions) if (m.plan and m.plan.day_restrictions) else [],
            "eligible_services": [es.service_id for es in m.plan.eligible_services] if m.plan else [],
            "plan_services": plan_services,
            "benefits": benefits
        })

    preferred_stylist = max(stylist_freq.items(), key=lambda x: x[1])[0] if stylist_freq else "No Preference"
    preferred_services = [s["name"] for s in purchased_services[:3]]

    summary = {
        "id": customer.id,
        "first_name": customer.first_name,
        "last_name": customer.last_name or "",
        "full_name": f"{customer.first_name} {customer.last_name or ''}".strip(),
        "phone": customer.phone,
        "email": customer.email or "Not Provided",
        "gender": customer.gender or "Not Specified",
        "date_joined": customer.created_at.strftime("%d %b %Y"),
        "membership_status": active_membership_status,
        "membership_plan": active_membership_name or "None",
        "total_visits": len(visit_history),
        "total_bills": len(visit_history),
        "total_amount_spent": float(grand_total_spent),
        "last_visit_date": visit_history[0]["date"] if visit_history else "No Visits Yet",
        "loyalty_points": len(visit_history) * 10,
        "preferred_stylist": preferred_stylist,
        "preferred_services": preferred_services,
        "notes": customer.notes or "Regular salon visitor. Prefers organic hair products.",
        "allergies": "None Reported"
    }

    financial_summary = {
        "total_bills": len(visit_history),
        "total_services_amount": float(total_services_amount),
        "total_products_amount": float(total_products_amount),
        "total_discounts_given": float(total_discounts_given),
        "total_tax_paid": float(total_tax_paid),
        "grand_total_spent": float(grand_total_spent)
    }

    return success_response({
        "summary": summary,
        "visit_history": visit_history,
        "purchased_services": purchased_services,
        "purchased_products": purchased_products,
        "memberships": memberships_data,
        "financial_summary": financial_summary,
        "timeline": timeline,
        "upcoming_appointments": []
    })


@customers_bp.route("/customers/dormant", methods=["GET"])
@require_role(["ParlourAdmin", "BranchAdmin"])
def get_dormant_customers():
    setting = TenantSetting.query.filter_by(tenant_id=g.parlour_id, branch_id=g.branch_id if g.role == "BranchAdmin" else None).first()
    threshold_days = setting.churn_days_threshold if setting and setting.churn_days_threshold else 45

    now = datetime.utcnow()
    limit_date = now - timedelta(days=threshold_days)

    # Build invoice subquery with branch isolation
    invoice_filter = [
        Invoice.tenant_id == g.parlour_id,
        Invoice.status != "Voided"
    ]
    if g.role == "BranchAdmin" and g.branch_id:
        invoice_filter.append(Invoice.branch_id == g.branch_id)

    subquery = db.session.query(
        Invoice.customer_id,
        func.max(Invoice.created_at).label("last_visit")
    ).filter(
        *invoice_filter
    ).group_by(Invoice.customer_id).subquery()

    query = db.session.query(
        Customer,
        subquery.c.last_visit
    ).filter(
        Customer.tenant_id == g.parlour_id
    )
    
    # Add branch filter for BranchAdmin
    if g.role == "BranchAdmin" and g.branch_id:
        query = query.filter(Customer.branch_id == g.branch_id)
    
    query = query.outerjoin(
        subquery, Customer.id == subquery.c.customer_id
    )

    query = query.filter(
        or_(
            subquery.c.last_visit < limit_date,
            and_(
                subquery.c.last_visit == None,
                Customer.created_at < limit_date
            )
        )
    )

    results = query.limit(100).all()

    data = []
    for customer, last_visit in results:
        ref_date = last_visit or customer.created_at
        days_since = (now - ref_date).days
        
        data.append({
            "id": customer.id,
            "first_name": customer.first_name,
            "last_name": customer.last_name or "",
            "phone": customer.phone,
            "email": customer.email or "",
            "gender": customer.gender or "",
            "last_visit_date": last_visit.isoformat() if last_visit else None,
            "days_inactive": days_since,
            "created_at": customer.created_at.isoformat()
        })

    data.sort(key=lambda x: x["days_inactive"], reverse=True)

    return success_response({
        "items": data,
        "threshold_days": threshold_days
    })
